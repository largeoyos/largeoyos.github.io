"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x01():
    rng=np.random.default_rng(7)
    identities=rng.normal(size=(40,8)); labels=rng.integers(0,2,40)
    def predict(train,train_y,test):
        return train_y[((test[:,None]-train[None,:])**2).sum(-1).argmin(1)]
    train=identities+rng.normal(0,.01,identities.shape)
    same=identities+rng.normal(0,.01,identities.shape)
    overlap=float((predict(train,labels,same)==labels).mean())
    held=float((predict(train[:20],labels[:20],same[20:])==labels[20:]).mean())
    assert overlap==1 and held<overlap
    return dict(overlapping_identity_accuracy=overlap,held_out_identity_accuracy=held,explanation='随机标签与身份独立；前者只证明身份记忆，不证明可推广规律。')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X01")
