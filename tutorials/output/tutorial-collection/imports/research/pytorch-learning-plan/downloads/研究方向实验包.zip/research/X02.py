"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def iou(a,b):
    area=lambda r:max(0,r[2]-r[0])*max(0,r[3]-r[1])
    intersection=area([max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])])
    union=area(a)+area(b)-intersection
    return intersection/union if union else 0.

def x02():
    boxes=np.array([[0,0,2,2],[.2,.2,2.2,2.2],[5,5,7,7.]])
    order=[0,1,2];keep=[]
    while order:
        best=order.pop(0);keep.append(best)
        order=[j for j in order if iou(boxes[best],boxes[j])<=.5]
    assert keep==[0,2] and abs(iou([0,0,2,2],[1,1,3,3])-1/7)<1e-12
    return dict(pair_iou=iou(boxes[0],boxes[1]),nms_kept=keep,coordinate_convention='连续坐标 xyxy，面积不加一；单类别、分数顺序固定')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X02")
