"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x03():
    rng=np.random.default_rng(4);a=rng.normal(size=(32,32));b=np.zeros_like(a);b[2:,3:]=a[:-2,:-3]
    scores=[]
    for dy in range(-4,5):
        for dx in range(-4,5):
            # Fixed interior support ensures comparable domains and no circular wrap.
            mse=float(((a[5:27,5:27]-b[5+dy:27+dy,5+dx:27+dx])**2).mean())
            scores.append((mse,dx,dy))
    mse,dx,dy=min(scores);assert (dx,dy)==(3,2) and mse==0
    return dict(dx=dx,dy=dy,mse=mse,range='正值代表向右、向下；只比较共同有效区域')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X03")
