"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def inverse_problem(kind):
    n=40;t=np.linspace(0,1,n);x=np.sin(2*np.pi*t)+.2*np.cos(6*np.pi*t)
    rng=np.random.default_rng(3)
    if kind=='blur':
        A=np.eye(n)*.5+np.roll(np.eye(n),1,axis=0)*.25+np.roll(np.eye(n),-1,axis=0)*.25
    else:
        q,_=np.linalg.qr(rng.normal(size=(n,n)));v,_=np.linalg.qr(rng.normal(size=(n,n)))
        A=q@np.diag(np.geomspace(1,.001,n))@v.T
    y=A@x+rng.normal(0,.01,n);rows=[]
    for lam in [0,1e-5,1e-3,.01,.1]:
        estimate=np.linalg.lstsq(A,y,rcond=None)[0] if lam==0 else np.linalg.solve(A.T@A+lam*np.eye(n),A.T@y)
        rows.append(dict(regularization=lam,mse=float(np.mean((estimate-x)**2)),residual=float(np.mean((A@estimate-y)**2))))
    assert all(np.isfinite(r['mse']) for r in rows)
    return dict(operator=kind,condition_number=float(np.linalg.cond(A)),results=rows,note='有真值的合成诊断；真实场景不能用测试真值选择正则系数。')

def x04():return inverse_problem('blur')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X04")
