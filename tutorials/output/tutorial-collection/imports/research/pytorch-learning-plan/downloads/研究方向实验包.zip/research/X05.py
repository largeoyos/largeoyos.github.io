"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x05():
    # Analytic Gaussian posterior, NOT a learned DDPM.
    rng=np.random.default_rng(8);clean=rng.normal(2,1,20000);eps=rng.normal(size=len(clean));rows=[]
    for alpha in [.1,.5,.9]:
        noisy=np.sqrt(alpha)*clean+np.sqrt(1-alpha)*eps
        posterior_mean=2+np.sqrt(alpha)*(noisy-np.sqrt(alpha)*2)
        unconditional=np.full_like(clean,2.)
        mse=float(np.mean((posterior_mean-clean)**2));assert mse<np.mean((unconditional-clean)**2)
        rows.append(dict(alpha_bar=alpha,observed_mse=mse,theoretical_mse=1-alpha))
    return dict(results=rows,meaning='高斯数据的一步条件均值；不训练神经网络，不生成自然图像。')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X05")
