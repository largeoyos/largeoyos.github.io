"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x06():
    f=800.;baseline=.2;point=np.array([.3,.1,2.]);u=f*point[0]/point[2];v=f*point[1]/point[2]
    ur=f*(point[0]-baseline)/point[2];disparity=u-ur;depth=f*baseline/disparity
    assert np.isclose(depth,point[2])
    return dict(left_uv=[u,v],right_u=ur,disparity_pixels=disparity,depth_m=depth,depth_with_one_pixel_error=f*baseline/(disparity+1),assumption='已校正平行双目；主点为零；焦距像素、基线米')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X06")
