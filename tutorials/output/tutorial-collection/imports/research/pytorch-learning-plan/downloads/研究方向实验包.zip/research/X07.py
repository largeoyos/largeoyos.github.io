"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x07():
    rng=np.random.default_rng(9);p=rng.uniform(0,1,(1000,3));voxel=.2
    a=np.unique(np.floor(p/voxel).astype(int),axis=0);b=np.unique(np.floor(p[rng.permutation(len(p))]/voxel).astype(int),axis=0)
    assert np.array_equal(a,b)
    coarse=np.unique(np.floor(p/.4).astype(int),axis=0)
    assert len(coarse)<=len(a)
    return dict(points=len(p),occupied_voxels=len(a),coarse_voxels=len(coarse),permutation_invariant=True,note='计数不是压缩文件大小；体素化会丢失体素内位置。')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X07")
