"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x09():
    n=97;m=129;y,x=np.mgrid[:n,:m]
    rgb=np.stack([x*255/(m-1),y*255/(n-1),127+100*np.sin(x/4)*np.cos(y/7)],-1).clip(0,255).astype('uint8')
    image=Image.fromarray(rgb);OUT.mkdir(exist_ok=True);original=OUT/'source.png';image.save(original)
    rows=[]
    for quality in [30,60,90]:
        path=OUT/f'jpeg_q{quality}.jpg';t=time.perf_counter();image.save(path,quality=quality,subsampling=0);encode=time.perf_counter()-t
        t=time.perf_counter()
        with Image.open(path) as im: reconstructed=np.array(im.convert('RGB'))
        decode=time.perf_counter()-t
        assert reconstructed.shape==rgb.shape
        mse=float(np.mean(((rgb.astype(float)-reconstructed.astype(float))/255.)**2))
        psnr=float('inf') if mse==0 else 10*math.log10(1/mse)
        rows.append(dict(quality=quality,height=n,width=m,file_bytes=path.stat().st_size,file_bpp=8*path.stat().st_size/(n*m),psnr_rgb=psnr,encode_s=encode,decode_s=decode))
    assert all(np.isfinite(r['psnr_rgb']) for r in rows)
    with (OUT/'jpeg_measurements.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    return dict(results=rows,source_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),measurement='真实JPEG文件；bpp含文件头，未单独拆熵流；计时含写文件及解码读文件；单次计时不作性能结论。',scope='一张合成图用于尺寸和公式自检，不是自然图基准。')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X09")
