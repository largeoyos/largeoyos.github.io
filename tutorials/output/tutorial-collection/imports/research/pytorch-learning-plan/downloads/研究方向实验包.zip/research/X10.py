"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x10():
    x=np.array([-.92,-.11,.37,.99]);step=.1;q=np.clip(np.rint(x/step),-128,127).astype('int8');back=q.astype(float)*step
    err=float(np.max(np.abs(back-x)));assert err<=step/2+1e-12
    channels=np.array([[.01,.02,.03],[1.,2.,3.]])
    per_tensor=np.rint(channels/(3/127))*(3/127)
    scales=np.max(np.abs(channels),axis=1,keepdims=True)/127
    per_channel=np.rint(channels/scales)*scales
    return dict(step=step,quantized=q.tolist(),restored=back.tolist(),max_error=err,per_tensor_mse=float(np.mean((channels-per_tensor)**2)),per_channel_mse=float(np.mean((channels-per_channel)**2)),note='ties-to-even；没有饱和时半步长界成立；不模拟整数卷积加速。')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X10")
