"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x11():
    images=np.array([[1.,0.,0.],[0.,1.,0.],[.6,.8,0.]])
    texts=np.array([[1.,0.,0.],[0.,1.,0.],[.8,.6,0.]])
    normalize=lambda z:z/np.linalg.norm(z,axis=-1,keepdims=True)
    scores=normalize(images)@normalize(texts).T
    ranked=np.argsort(-scores,axis=1);assert ranked[0,0]==0 and ranked[1,0]==1
    return dict(similarities=scores.tolist(),ranked_text_ids=ranked.tolist(),paired_recall_at_1=float(np.mean(ranked[:,0]==np.arange(3))),meaning='手工向量演示检索。不是运行CLIP，也不证明自然语言理解。')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X11")
