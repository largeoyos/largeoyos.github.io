"""独立可运行的教学参考实现；范围与限制见教材实验区。"""
import csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/"outputs"

def x12():
    y=np.array([0]*95+[1]*5);all_background=np.zeros(100,dtype=int);model=np.zeros(100,dtype=int);model[95:99]=1;model[0:6]=1
    def metrics(pred):
        tp=int(np.sum((pred==1)&(y==1)));fp=int(np.sum((pred==1)&(y==0)));fn=int(np.sum((pred==0)&(y==1)))
        return dict(accuracy=float(np.mean(pred==y)),precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/(tp+fn),dice=2*tp/(2*tp+fp+fn))
    a,b=metrics(all_background),metrics(model);assert a['accuracy']>b['accuracy'] and a['dice']<b['dice']
    return dict(background=a,model=b,meaning='二分类合成像素；前景缺失时精确率约定为零；同病人切片不能作为独立样本估置信区间。')

def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record

if __name__=="__main__":
    main("X12")
