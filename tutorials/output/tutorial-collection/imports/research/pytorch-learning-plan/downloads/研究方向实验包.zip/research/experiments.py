"""Twelve small, deterministic teaching experiments. Python + NumPy + Pillow."""
import argparse, csv, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
OUT=Path(__file__).resolve().parent/'outputs'
def x01():
    rng=np.random.default_rng(7)
    identities=rng.normal(size=(40,8)); labels=rng.integers(0,2,40)
    def predict(train,train_y,test):
        return train_y[((test[:,None]-train[None,:])**2).sum(-1).argmin(1)]
    train=identities+rng.normal(0,.01,identities.shape)
    same=identities+rng.normal(0,.01,identities.shape)
    overlap=float((predict(train,labels,same)==labels).mean())
    held=float((predict(train[:20],labels[:20],same[20:])==labels[20:]).mean())
    assert overlap==1 and held<overlap
    return dict(overlapping_identity_accuracy=overlap,held_out_identity_accuracy=held,explanation='随机标签与身份独立；前者只证明身份记忆，不证明可推广规律。')
def iou(a,b):
    area=lambda r:max(0,r[2]-r[0])*max(0,r[3]-r[1])
    intersection=area([max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])])
    union=area(a)+area(b)-intersection
    return intersection/union if union else 0.
def x02():
    boxes=np.array([[0,0,2,2],[.2,.2,2.2,2.2],[5,5,7,7.]])
    order=[0,1,2];keep=[]
    while order:
        best=order.pop(0);keep.append(best)
        order=[j for j in order if iou(boxes[best],boxes[j])<=.5]
    assert keep==[0,2] and abs(iou([0,0,2,2],[1,1,3,3])-1/7)<1e-12
    return dict(pair_iou=iou(boxes[0],boxes[1]),nms_kept=keep,coordinate_convention='连续坐标 xyxy，面积不加一；单类别、分数顺序固定')
def x03():
    rng=np.random.default_rng(4);a=rng.normal(size=(32,32));b=np.zeros_like(a);b[2:,3:]=a[:-2,:-3]
    scores=[]
    for dy in range(-4,5):
        for dx in range(-4,5):
            # Fixed interior support ensures comparable domains and no circular wrap.
            mse=float(((a[5:27,5:27]-b[5+dy:27+dy,5+dx:27+dx])**2).mean())
            scores.append((mse,dx,dy))
    mse,dx,dy=min(scores);assert (dx,dy)==(3,2) and mse==0
    return dict(dx=dx,dy=dy,mse=mse,range='正值代表向右、向下；只比较共同有效区域')
def inverse_problem(kind):
    n=40;t=np.linspace(0,1,n);x=np.sin(2*np.pi*t)+.2*np.cos(6*np.pi*t)
    rng=np.random.default_rng(3)
    if kind=='blur':
        A=np.eye(n)*.5+np.roll(np.eye(n),1,axis=0)*.25+np.roll(np.eye(n),-1,axis=0)*.25
    else:
        q,_=np.linalg.qr(rng.normal(size=(n,n)));v,_=np.linalg.qr(rng.normal(size=(n,n)))
        A=q@np.diag(np.geomspace(1,.001,n))@v.T
    y=A@x+rng.normal(0,.01,n);rows=[]
    for lam in [0,1e-5,1e-3,.01,.1]:
        estimate=np.linalg.lstsq(A,y,rcond=None)[0] if lam==0 else np.linalg.solve(A.T@A+lam*np.eye(n),A.T@y)
        rows.append(dict(regularization=lam,mse=float(np.mean((estimate-x)**2)),residual=float(np.mean((A@estimate-y)**2))))
    assert all(np.isfinite(r['mse']) for r in rows)
    return dict(operator=kind,condition_number=float(np.linalg.cond(A)),results=rows,note='有真值的合成诊断；真实场景不能用测试真值选择正则系数。')
def x04():return inverse_problem('blur')
def x05():
    # Analytic Gaussian posterior, NOT a learned DDPM.
    rng=np.random.default_rng(8);clean=rng.normal(2,1,20000);eps=rng.normal(size=len(clean));rows=[]
    for alpha in [.1,.5,.9]:
        noisy=np.sqrt(alpha)*clean+np.sqrt(1-alpha)*eps
        posterior_mean=2+np.sqrt(alpha)*(noisy-np.sqrt(alpha)*2)
        unconditional=np.full_like(clean,2.)
        mse=float(np.mean((posterior_mean-clean)**2));assert mse<np.mean((unconditional-clean)**2)
        rows.append(dict(alpha_bar=alpha,observed_mse=mse,theoretical_mse=1-alpha))
    return dict(results=rows,meaning='高斯数据的一步条件均值；不训练神经网络，不生成自然图像。')
def x06():
    f=800.;baseline=.2;point=np.array([.3,.1,2.]);u=f*point[0]/point[2];v=f*point[1]/point[2]
    ur=f*(point[0]-baseline)/point[2];disparity=u-ur;depth=f*baseline/disparity
    assert np.isclose(depth,point[2])
    return dict(left_uv=[u,v],right_u=ur,disparity_pixels=disparity,depth_m=depth,depth_with_one_pixel_error=f*baseline/(disparity+1),assumption='已校正平行双目；主点为零；焦距像素、基线米')
def x07():
    rng=np.random.default_rng(9);p=rng.uniform(0,1,(1000,3));voxel=.2
    a=np.unique(np.floor(p/voxel).astype(int),axis=0);b=np.unique(np.floor(p[rng.permutation(len(p))]/voxel).astype(int),axis=0)
    assert np.array_equal(a,b)
    coarse=np.unique(np.floor(p/.4).astype(int),axis=0)
    assert len(coarse)<=len(a)
    return dict(points=len(p),occupied_voxels=len(a),coarse_voxels=len(coarse),permutation_invariant=True,note='计数不是压缩文件大小；体素化会丢失体素内位置。')
def x08():return inverse_problem('coded')
def x09():
    n=97;m=129;y,x=np.mgrid[:n,:m]
    rgb=np.stack([x*255/(m-1),y*255/(n-1),127+100*np.sin(x/4)*np.cos(y/7)],-1).clip(0,255).astype('uint8')
    image=Image.fromarray(rgb);OUT.mkdir(exist_ok=True);original=OUT/'source.png';image.save(original)
    rows=[]
    for quality in [30,60,90]:
        path=OUT/f'jpeg_q{quality}.jpg';t=time.perf_counter();image.save(path,quality=quality,subsampling=0);encode=time.perf_counter()-t
        t=time.perf_counter()
        with Image.open(path) as im: reconstructed=np.array(im.convert('RGB'))
        decode=time.perf_counter()-t
        assert reconstructed.shape==rgb.shape
        mse=float(np.mean(((rgb.astype(float)-reconstructed.astype(float))/255.)**2))
        psnr=float('inf') if mse==0 else 10*math.log10(1/mse)
        rows.append(dict(quality=quality,height=n,width=m,file_bytes=path.stat().st_size,file_bpp=8*path.stat().st_size/(n*m),psnr_rgb=psnr,encode_s=encode,decode_s=decode))
    assert all(np.isfinite(r['psnr_rgb']) for r in rows)
    with (OUT/'jpeg_measurements.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    return dict(results=rows,source_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),measurement='真实JPEG文件；bpp含文件头，未单独拆熵流；计时含写文件及解码读文件；单次计时不作性能结论。',scope='一张合成图用于尺寸和公式自检，不是自然图基准。')
def x10():
    x=np.array([-.92,-.11,.37,.99]);step=.1;q=np.clip(np.rint(x/step),-128,127).astype('int8');back=q.astype(float)*step
    err=float(np.max(np.abs(back-x)));assert err<=step/2+1e-12
    channels=np.array([[.01,.02,.03],[1.,2.,3.]])
    per_tensor=np.rint(channels/(3/127))*(3/127)
    scales=np.max(np.abs(channels),axis=1,keepdims=True)/127
    per_channel=np.rint(channels/scales)*scales
    return dict(step=step,quantized=q.tolist(),restored=back.tolist(),max_error=err,per_tensor_mse=float(np.mean((channels-per_tensor)**2)),per_channel_mse=float(np.mean((channels-per_channel)**2)),note='ties-to-even；没有饱和时半步长界成立；不模拟整数卷积加速。')
def x11():
    images=np.array([[1.,0.,0.],[0.,1.,0.],[.6,.8,0.]])
    texts=np.array([[1.,0.,0.],[0.,1.,0.],[.8,.6,0.]])
    normalize=lambda z:z/np.linalg.norm(z,axis=-1,keepdims=True)
    scores=normalize(images)@normalize(texts).T
    ranked=np.argsort(-scores,axis=1);assert ranked[0,0]==0 and ranked[1,0]==1
    return dict(similarities=scores.tolist(),ranked_text_ids=ranked.tolist(),paired_recall_at_1=float(np.mean(ranked[:,0]==np.arange(3))),meaning='手工向量演示检索。不是运行CLIP，也不证明自然语言理解。')
def x12():
    y=np.array([0]*95+[1]*5);all_background=np.zeros(100,dtype=int);model=np.zeros(100,dtype=int);model[95:99]=1;model[0:6]=1
    def metrics(pred):
        tp=int(np.sum((pred==1)&(y==1)));fp=int(np.sum((pred==1)&(y==0)));fn=int(np.sum((pred==0)&(y==1)))
        return dict(accuracy=float(np.mean(pred==y)),precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/(tp+fn),dice=2*tp/(2*tp+fp+fn))
    a,b=metrics(all_background),metrics(model);assert a['accuracy']>b['accuracy'] and a['dice']<b['dice']
    return dict(background=a,model=b,meaning='二分类合成像素；前景缺失时精确率约定为零；同病人切片不能作为独立样本估置信区间。')
def main(identifier):
    result=globals()[identifier.lower()]();OUT.mkdir(exist_ok=True)
    record={'experiment':identifier,'environment':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'platform':platform.platform()},'result':result}
    (OUT/(identifier+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
    return record
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('id',choices=[f'X{i:02}' for i in range(1,13)]);main(parser.parse_args().id)
