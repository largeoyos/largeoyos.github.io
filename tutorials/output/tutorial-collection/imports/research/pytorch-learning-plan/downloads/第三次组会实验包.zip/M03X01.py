"""Synthetic candidate omission and largest-remainder allocation; no video model."""
import json
def allocate(weights, budget):
    assert budget >= 0 and weights and all(w >= 0 for w in weights) and sum(weights)>0
    raw=[budget*w/sum(weights) for w in weights]
    counts=[int(x) for x in raw]
    order=sorted(range(len(weights)),key=lambda i:(-(raw[i]-counts[i]),i))
    for i in order[:budget-sum(counts)]: counts[i]+=1
    assert sum(counts)==budget
    return counts
def main():
    candidates=list(range(0,100,10));critical=43
    selected=sorted(candidates,key=lambda x:abs(x-critical))[:4]
    assert critical not in selected
    enriched=sorted(set(candidates+[critical]))
    improved=sorted(enriched,key=lambda x:abs(x-critical))[:4]
    assert critical in improved and len(set(improved))==4
    counts=allocate([1,3,2,2],6)
    assert counts==[1,2,2,1]
    print(json.dumps(dict(experiment='M03X01',missed=critical not in selected,recovered=critical in improved,allocation=counts,budget=sum(counts))))
if __name__=='__main__':main()
