"""Two-dimensional codebook lookup, not QR codes or VQ-VAE training."""
import json
def nearest(point, book):
    distances=[sum((a-b)**2 for a,b in zip(point,word)) for word in book]
    i=min(range(len(book)),key=lambda j:distances[j])
    return i,distances[i]
def main():
    book=[(0,0),(1,0),(0,1),(1,1)]
    points=[(.8,.2),(.1,.1),(.2,.9),(.9,.8)]
    result=[nearest(p,book) for p in points]
    assert result[0][0]==1 and abs(result[0][1]-.08)<1e-12
    before=sum(d for i,d in result)/len(result)
    larger=book+[(.8,.2)]
    after=sum(nearest(p,larger)[1] for p in points)/len(points)
    assert after<=before
    print(json.dumps(dict(experiment='M03X02',indices=[i for i,d in result],mean_squared_distance=before,expanded_error=after,used_codes=len(set(i for i,d in result)),dimension=2)))
if __name__=='__main__':main()
