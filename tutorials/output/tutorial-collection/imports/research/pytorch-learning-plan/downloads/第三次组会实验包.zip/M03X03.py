"""Synthetic 7x5 glyph: pixel error versus a predefined middle-stroke predicate."""
import json
def mse(a,b):return sum((x-y)**2 for x,y in zip(a,b))/len(a)
def middle(g):return all(g[3*5+c]>.5 for c in range(1,4))
def main():
    glyph=[float(c==0 or c==4 or r in (0,3,6)) for r in range(7) for c in range(5)]
    missing=glyph.copy()
    for c in range(1,4):missing[3*5+c]=0
    faded=[.6 if v else .4 for v in glyph]
    assert mse(glyph,missing)<mse(glyph,faded)
    assert not middle(missing) and middle(faded)
    print(json.dumps(dict(experiment='M03X03',missing_mse=mse(glyph,missing),faded_mse=mse(glyph,faded),missing_structure=middle(missing),faded_structure=middle(faded),warning='Synthetic predicate, not OCR accuracy')))
if __name__=='__main__':main()
