from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson01():
    def summarize(values):
        if not values: raise ValueError('values must not be empty')
        mean=sum(values)/len(values)
        return dict(count=len(values),total=sum(values),mean=mean,above_mean=[x for x in values if x>mean])
    result=summarize([30,45,20,60,25]); assert result['mean']==36
    try: summarize([])
    except ValueError: pass
    else: raise AssertionError('empty input not rejected')
    path=emit('L01.json',result)
    assert json.loads(path.read_text(encoding='utf-8'))==result
    print(result)

if __name__ == "__main__":
    lesson01()
