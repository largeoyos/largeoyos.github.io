from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson02():
    hwc=torch.arange(16*20*3,dtype=torch.int64).reshape(16,20,3)%256
    x=hwc.float().permute(2,0,1).unsqueeze(0)/255
    assert x.shape==(1,3,16,20) and 0<=x.min()<=x.max()<=1
    means=x.mean(dim=(0,2,3)); print(x.shape,means)
    restored=(x.squeeze(0).permute(1,2,0)*255).round().long()
    assert torch.equal(restored,hwc)

if __name__ == "__main__":
    lesson02()
