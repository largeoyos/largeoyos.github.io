from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson03():
    seed(); x=torch.linspace(-1,1,50).unsqueeze(1); y=2*x+1
    model=nn.Linear(1,1); opt=torch.optim.SGD(model.parameters(),lr=.1)
    before=[p.detach().clone() for p in model.parameters()]; history=[]
    for _ in range(150):
        loss=F.mse_loss(model(x),y); assert torch.isfinite(loss)
        opt.zero_grad(); loss.backward(); opt.step(); history.append(loss.item())
    assert history[-1]<history[0] and abs(model.weight.item()-2)<.02
    assert any(not torch.equal(a,b) for a,b in zip(before,model.parameters()))
    print('w,b,initial,final:',model.weight.item(),model.bias.item(),history[0],history[-1])
    emit('L03.json',history)

if __name__ == "__main__":
    lesson03()
