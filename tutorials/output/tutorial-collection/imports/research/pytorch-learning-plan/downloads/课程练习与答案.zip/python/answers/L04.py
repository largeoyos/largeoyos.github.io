from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson04():
    x,y=stripes(10); loader=DataLoader(TensorDataset(x,y),batch_size=4,shuffle=False)
    sizes=[]
    for xb,yb in loader:
        print(xb.shape,yb.shape,yb.dtype); sizes.append(len(xb))
    assert sizes==[4,4,2] and sum(sizes)==10

if __name__ == "__main__":
    lesson04()
