from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson05():
    seed(); model=classifier(); history=fit_classifier(model)
    assert history[-1]<history[0]; print('loss:',history)
    print('parameters:',sum(p.numel() for p in model.parameters()))
    emit('L05.json',history)

if __name__ == "__main__":
    lesson05()
