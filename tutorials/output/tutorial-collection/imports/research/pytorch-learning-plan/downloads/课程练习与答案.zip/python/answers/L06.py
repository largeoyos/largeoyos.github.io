from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson06():
    seed(); model=classifier(); fit_classifier(model)
    x,y=stripes(random_seed=99); scores=evaluate(model,x,y)
    path=OUT/'L06.pt'; torch.save(model.state_dict(),path)
    restored=classifier(); restored.load_state_dict(torch.load(path,map_location='cpu',weights_only=True)); restored.eval()
    with torch.inference_mode(): assert torch.allclose(model(x),restored(x))
    print(scores,'reload checked'); emit('L06.json',scores)

if __name__ == "__main__":
    lesson06()
