from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson07():
    def output_size(h,k,p,s,d=1): return (h+2*p-d*(k-1)-1)//s+1
    for h,k,p,s in [(32,3,1,2),(31,5,2,2),(17,3,0,1)]:
        layer=nn.Conv2d(3,8,k,stride=s,padding=p)
        y=layer(torch.zeros(1,3,h,h)); expected=output_size(h,k,p,s)
        assert y.shape[-1]==expected
        assert sum(x.numel() for x in layer.parameters())==8*(3*k*k+1)
        print(h,'->',y.shape,'parameters',8*(3*k*k+1))

if __name__ == "__main__":
    lesson07()
