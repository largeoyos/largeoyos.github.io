from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson08():
    seed(); model=classifier(cnn=True); history=fit_classifier(model)
    clean=evaluate(model,*stripes(random_seed=98)); noisy=evaluate(model,*stripes(noise=.8,random_seed=99))
    emit('L08.json',dict(synthetic=True,train_loss=history,validation=clean,noisy_validation=noisy))
    print(clean,noisy)

if __name__ == "__main__":
    lesson08()
