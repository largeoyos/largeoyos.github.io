from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson09():
    args=cli(); img=Image.open(args.image).convert('RGB') if args.image else to_image(picture(96))
    name=Path(args.image).name if args.image else 'synthetic-demo'
    rows=[jpeg_row(img,q,name) for q in [20,50,85]]
    for r in rows: print(r['quality'],r['file_bpp'],r['psnr'])
    assert psnr(pil_tensor(img),pil_tensor(img))==math.inf
    csv_write('L09_jpeg.csv',rows)
    to_image(picture(96)).save(OUT/'synthetic-demo.png')

if __name__ == "__main__":
    lesson09()
