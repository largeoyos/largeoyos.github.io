from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson10():
    seed(); model=Autoencoder(); x=picture()
    for layer in model.encoder:
        x=layer(x); print(type(layer).__name__,tuple(x.shape))
    assert x.shape==(1,8,8,8)
    out=model(picture()); assert out.shape==picture().shape
    print('input/latent values:',picture().numel(),x.numel())

if __name__ == "__main__":
    lesson10()
