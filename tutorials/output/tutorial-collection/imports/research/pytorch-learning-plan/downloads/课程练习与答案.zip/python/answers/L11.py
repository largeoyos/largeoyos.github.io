from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson11():
    model,record=fit_autoencoder(); x=picture()
    with torch.inference_mode(): y=model(x)
    to_image(x).save(OUT/'L11_original.png'); to_image(y).save(OUT/'L11_reconstruction.png')
    to_image((x-y).abs()*4).save(OUT/'L11_error_x4.png')
    torch.save(model.state_dict(),OUT/'L11.pt'); emit('L11.json',record); print(record)

if __name__ == "__main__":
    lesson11()
