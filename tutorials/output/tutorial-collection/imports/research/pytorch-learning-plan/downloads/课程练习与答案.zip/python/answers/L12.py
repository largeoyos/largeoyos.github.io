from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson12():
    y=torch.linspace(-2,2,101)
    for step in [.1,.5,1.]:
        q=torch.round(y/step); reconstructed=q*step; error=(y-reconstructed).abs()
        assert error.max()<=step/2+1e-6
        print('step,max_error,symbols:',step,float(error.max()),len(q.unique()))
    y=torch.tensor([.37],requires_grad=True)
    ste=y+(y.round()-y).detach(); ste.sum().backward(); assert y.grad.item()==1

if __name__ == "__main__":
    lesson12()
