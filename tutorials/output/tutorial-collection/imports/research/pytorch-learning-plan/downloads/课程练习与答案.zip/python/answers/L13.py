from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson13():
    probabilities=[.5,.25,.125,.125]
    bits=[-math.log2(p) for p in probabilities]
    cdf=lambda x:.5*(1+math.erf(x/math.sqrt(2)))
    mass=cdf(.5)-cdf(-.5)
    assert bits==[1,2,3,3] and 0<mass<1
    print('bits:',bits,'standard normal mass [-.5,.5]:',mass)

if __name__ == "__main__":
    lesson13()
