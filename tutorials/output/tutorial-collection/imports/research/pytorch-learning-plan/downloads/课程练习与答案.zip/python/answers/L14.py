from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson14():
    def cross_entropy(p,q):
        return sum(-a*math.log2(b) if b>0 else math.inf for a,b in zip(p,q) if a>0)
    p=[.75,.25]; h=cross_entropy(p,p); cross=cross_entropy(p,[.5,.5])
    assert abs(h-.811278124459)<1e-8 and cross>=h
    print('entropy,cross_entropy,KL:',h,cross,cross-h)

if __name__ == "__main__":
    lesson14()
