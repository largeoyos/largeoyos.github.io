from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson15():
    likelihood=torch.tensor([.5,.25,.125,.125]).reshape(1,1,2,2)
    rate=-likelihood.log2().sum()/4; mse=torch.tensor(.01)
    for lam in [1,10,100]: print('R,D,L:',rate.item(),mse.item(),(rate+lam*mse).item())
    assert rate.item()==2.25
    print('scaled MSE:',float(mse*255**2),'not the same lambda convention')

if __name__ == "__main__":
    lesson15()
