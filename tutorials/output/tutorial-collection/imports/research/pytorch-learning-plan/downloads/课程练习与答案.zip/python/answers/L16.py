from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson16():
    args=cli(); root=Path(args.project)/'src'/'lic_study'
    for filename in ['model.py','train_toy.py','metrics.py']:
        p=root/filename
        if not p.exists(): raise FileNotFoundError(f'{p}: pass --project with the local study project')
        print('\n',p)
        for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
            if any(k in line for k in ['def forward','def likelihood','def rate_distortion','def estimated_bpp','rd_lambda']): print(i,line.strip())

if __name__ == "__main__":
    lesson16()
