from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson17():
    _,record=fit_autoencoder(steps=30)
    print('single-image diagnostic, NOT generalization:',record); emit('L17.json',record)

if __name__ == "__main__":
    lesson17()
