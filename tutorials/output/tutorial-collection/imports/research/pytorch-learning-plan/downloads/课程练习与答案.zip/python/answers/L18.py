from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson18():
    def digest(data): return hashlib.sha256(data).hexdigest()
    train={'a.png':digest(b'image A'),'b.png':digest(b'image B')}
    test={'renamed.png':digest(b'image A')}
    overlap=set(train.values())&set(test.values()); assert len(overlap)==1
    print('deliberate leakage detected:',overlap)
    test={'c.png':digest(b'image C')}; assert not set(train.values())&set(test.values())
    emit('L18_manifest_example.json',dict(synthetic_fixture=True,train=train,test=test,seed=42,range='0..1',device='cpu'))

if __name__ == "__main__":
    lesson18()
