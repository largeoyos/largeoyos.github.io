from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson19():
    import importlib.util
    report=dict(executable=sys.executable,system=platform.system(),python=sys.version,torch=torch.__version__,
      cuda=torch.cuda.is_available(),compressai_installed=importlib.util.find_spec('compressai') is not None)
    emit('L19_environment.json',report); print(report)
    print('Environment inspection only; does not install WSL or packages.')

if __name__ == "__main__":
    lesson19()
