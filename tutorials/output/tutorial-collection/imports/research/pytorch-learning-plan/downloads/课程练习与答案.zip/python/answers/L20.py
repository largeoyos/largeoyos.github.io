from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson20():
    args=cli()
    if not args.image: raise ValueError('Use --image /path/to/photo.png inside the Linux environment')
    img=Image.open(args.image).convert('RGB')
    row=real_encode(img,args.model,args.quality,OUT/'L20.lic'); row['image']=Path(args.image).name
    csv_write('L20.csv',[row]); print(row)

if __name__ == "__main__":
    lesson20()
