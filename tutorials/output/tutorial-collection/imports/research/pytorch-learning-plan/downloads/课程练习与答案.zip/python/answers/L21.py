from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson21():
    args=cli()
    if args.self_test:
        path=OUT/'L21_serializer_fixture.lic'
        pack_stream(path,dict(height=100,width=100),[[b'abc'],[b'xy']])
        meta,streams=unpack_stream(path); assert streams==[[b'abc'],[b'xy']]
        print('SERIALIZER TEST ONLY: arbitrary bytes, NOT an entropy coding result')
    else:
        if not args.bitstream: raise ValueError('Pass --bitstream outputs/L20.lic')
        path=Path(args.bitstream); meta,streams=unpack_stream(path)
        model=load_codec(meta['model'],int(meta['quality']))
        with torch.inference_mode():
            decoded=model.decompress(streams,meta['shape'])['x_hat'][...,:meta['height'],:meta['width']].clamp(0,1)
        assert tuple(decoded.shape)==(1,3,meta['height'],meta['width'])
        reconstructed=OUT/'L21_decoded.png'
        to_image(decoded).save(reconstructed)
        print('Decoded from stored bytes in a fresh process:',reconstructed,tuple(decoded.shape))
    payload=sum(len(s) for group in streams for s in group); total=path.stat().st_size
    assert total>payload
    print(dict(payload_bytes=payload,header_bytes=total-payload,payload_bpp=bpp(payload,meta['height'],meta['width']),file_bpp=bpp(total,meta['height'],meta['width'])))

if __name__ == "__main__":
    lesson21()
