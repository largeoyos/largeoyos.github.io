from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson22():
    args=cli()
    if not args.images: raise ValueError('Pass --images folder containing at least 5 fixed test images in Linux')
    print(benchmark(args.images))

if __name__ == "__main__":
    lesson22()
