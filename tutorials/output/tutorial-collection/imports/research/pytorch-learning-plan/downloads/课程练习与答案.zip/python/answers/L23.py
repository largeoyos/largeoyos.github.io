from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson23():
    args=cli()
    if not args.results: raise ValueError('Pass --results outputs/benchmark.csv, or explicitly use L09_jpeg.csv for a synthetic teaching plot')
    rows=read_csv(args.results); rd_svg(rows,OUT/'L23_RD.svg')
    print('source:',args.results,'Do not present synthetic-image plots as natural-image benchmark results.')

if __name__ == "__main__":
    lesson23()
