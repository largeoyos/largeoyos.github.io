from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson24():
    args=cli()
    if not args.results: raise ValueError('Pass --results with an actual CSV')
    rows=read_csv(args.results); assert rows
    text='# 第一份压缩实验报告\n\n数据来源：'+str(Path(args.results).resolve())+'\n\n'
    text+='原始记录数：'+str(len(rows))+'\n\n'
    text+='## 问题与设置\n请根据实际运行填写图片来源、模型、版本、设备、预处理、统计口径。\n\n'
    text+='## 两条观察\n逐条指向 CSV 或图片；区分观察与假设。\n\n## 限制\n说明样本量、速度计量和环境阻塞。\n\n## 下一步\n写一个可以用控制变量实验回答的问题。\n'
    path=OUT/'L24_report.md'; path.write_text(text,encoding='utf-8'); print(path)

if __name__ == "__main__":
    lesson24()
