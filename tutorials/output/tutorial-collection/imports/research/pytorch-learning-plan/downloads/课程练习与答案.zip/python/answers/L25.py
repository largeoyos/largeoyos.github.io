from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson25():
    p=torch.tensor([.5,.25,.125,.125]); symbols=torch.tensor([0,1,1,2,3])
    lengths=-p[symbols].log2(); assert float(lengths.sum())==11
    print('ideal factorized lengths:',lengths.tolist(),'total',float(lengths.sum()))
    print('No actual bitstream produced; model ignores dependencies.')

if __name__ == "__main__":
    lesson25()
