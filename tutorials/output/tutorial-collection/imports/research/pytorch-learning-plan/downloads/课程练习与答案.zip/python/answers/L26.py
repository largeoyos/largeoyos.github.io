from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson26():
    original=1000; conditioned=700
    rows=[]
    for side in [0,120,300,400]:
        total=conditioned+side; rows.append(dict(side=side,total=total,saving=original-total))
    assert rows[1]['saving']==180 and rows[2]['saving']==0
    print(rows)

if __name__ == "__main__":
    lesson26()
