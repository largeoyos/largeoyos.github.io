from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson27():
    args=cli()
    if not args.images: raise ValueError('Pass --images with the same fixed test folder in Linux')
    path=benchmark(args.images,include_hyper=True)
    rows=read_csv(path); rd_svg(rows,OUT/'L27_RD.svg')
    for r in rows:
        if r['model']=='hyperprior': print(r['image'],r['quality'],'side bytes:',r['side_bytes'])

if __name__ == "__main__":
    lesson27()
