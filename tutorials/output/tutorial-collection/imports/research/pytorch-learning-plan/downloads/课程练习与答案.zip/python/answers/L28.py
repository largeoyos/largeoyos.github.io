from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson28():
    def check(steps):
        known={'z'}
        for name,deps in steps:
            if not set(deps)<=known: raise ValueError(f'{name}: future dependency {set(deps)-known}')
            known.add(name)
        return known
    print(check([('y1',['z']),('y2',['z','y1'])]))
    try: check([('y1',['y2']),('y2',['z'])])
    except ValueError as e: print('correctly rejected:',e)
    else: raise AssertionError('leakage not detected')

if __name__ == "__main__":
    lesson28()
