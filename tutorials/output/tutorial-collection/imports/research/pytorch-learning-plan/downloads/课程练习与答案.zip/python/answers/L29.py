from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson29():
    seed(); q=torch.randn(3,4); k=torch.randn(3,4); v=torch.randn(3,2)
    scores=q@k.T/math.sqrt(q.shape[-1])
    mask=torch.triu(torch.ones(3,3,dtype=torch.bool),diagonal=1)
    weights=scores.masked_fill(mask,-torch.inf).softmax(dim=-1)
    out=weights@v
    assert out.shape==(3,2) and torch.allclose(weights.sum(-1),torch.ones(3))
    assert torch.all(weights[mask]==0)
    print('weights:',weights,'output:',out)

if __name__ == "__main__":
    lesson29()
