from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson30():
    args=cli(); root=Path(args.hpcm); p=root/'src'/'models'/'HPCM_Base.py'
    if not p.exists(): raise FileNotFoundError(f'{p}: use --hpcm with repository path')
    import subprocess
    result=subprocess.run(['git','-C',str(root),'rev-parse','HEAD'],capture_output=True,text=True)
    print('commit:',result.stdout.strip() or 'unavailable')
    for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        if any(k in line for k in ['def forward','context_next','y_hat_so_far','self.g_a(x)','self.h_a(y)']): print(i,line.strip())
    print('Static code reading only; original model has not been executed.')

if __name__ == "__main__":
    lesson30()
