from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson31():
    x=torch.tensor([-3.,-.9,-.1,0.,.26,.9,3.])
    for bits in [4,8,12]:
        qmax=2**(bits-1)-1; scale=1/qmax # calibrated range [-1,1], deliberate outliers
        q=(x/scale).round().clamp(-qmax,qmax); restored=q*scale
        print(bits,'MSE:',float(F.mse_loss(restored,x)),'saturated:',float((x.abs()>1).float().mean()))
    print('Fake quantization simulation; NOT an integer kernel speed benchmark.')

if __name__ == "__main__":
    lesson31()
