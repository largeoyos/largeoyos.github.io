from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson32():
    limit=2**31-1
    for count in [1,100,200000]:
        upper=count*128*128+100+64
        print('K,bound,fits_int32:',count,upper,upper<=limit)
    assert 200000*128*128>limit
    print('negative rounding: floor division',-3//2,'ties-to-even round',round(-3/2))

if __name__ == "__main__":
    lesson32()
