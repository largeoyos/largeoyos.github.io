from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson33():
    args=cli(); device='cuda' if args.cuda else 'cpu'
    if device=='cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA requested but unavailable')
    seed(); model=classifier(cnn=True).to(device).eval(); x=stripes(1)[0].to(device)
    sync=lambda: torch.cuda.synchronize() if device=='cuda' else None
    times=[]
    with torch.inference_mode():
        for _ in range(5): model(x)
        for _ in range(20):
            sync(); start=time.perf_counter(); model(x); sync(); times.append(time.perf_counter()-start)
    record=dict(device=device,shape=list(x.shape),parameters=sum(p.numel() for p in model.parameters()),
      median_seconds=statistics.median(times),min_seconds=min(times),max_seconds=max(times),scope='forward only; no codec or I/O',threads=torch.get_num_threads())
    print(record); emit('L33.json',record)

if __name__ == "__main__":
    lesson33()
