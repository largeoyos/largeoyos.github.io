from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson34():
    complexity=[4,2,1,1]; budget=4000
    bits=[budget*c//sum(complexity) for c in complexity]; bits[-1]+=budget-sum(bits)
    assert sum(bits)==budget
    print('heuristic allocation, NOT optimal rate control:',bits)
    rows=[dict(object='image',redundancy='spatial',metric='RGB PSNR / bpp'),
      dict(object='video',redundancy='temporal + spatial',metric='quality / bitrate / FPS'),
      dict(object='point cloud',redundancy='3D occupancy',metric='geometry distortion / bits per point'),
      dict(object='3D scene',redundancy='shared scene',metric='rendering quality / storage')]
    csv_write('L34_research_map.csv',rows)

if __name__ == "__main__":
    lesson34()
