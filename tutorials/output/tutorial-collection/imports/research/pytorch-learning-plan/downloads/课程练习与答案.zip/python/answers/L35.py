from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson35():
    rows=[]
    for random_seed in [11,22,33]:
        for channels in [4,8]:
            model,record=fit_autoencoder(channels=channels,steps=40,random_seed=random_seed)
            test=picture(random_seed=99)
            model.eval()
            with torch.inference_mode():
                for _ in range(5): model(test)
                timings=[]
                for _ in range(20):
                    t0=time.perf_counter()
                    pred=model(test)
                    timings.append((time.perf_counter()-t0)*1000)
                error=float(F.mse_loss(pred,test))
            rows.append(dict(channels=channels,seed=random_seed,steps=40,train_mse=record['final_mse'],
              test_mse=error,parameters=sum(p.numel() for p in model.parameters()),
              forward_median_ms=statistics.median(timings),device='cpu',warmup=5,timed_runs=20,synthetic=True))
    csv_write('L35_ablation.csv',rows)
    print('Different synthetic noise realization; not a diverse natural-image generalization benchmark.')

if __name__ == "__main__":
    lesson35()
