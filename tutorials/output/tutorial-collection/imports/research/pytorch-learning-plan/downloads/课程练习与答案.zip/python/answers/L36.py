from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson36():
    template='''# 十二周学习总结

## 能力与证据
分别列出：训练循环、保存加载、图像重建、真实码流、评价指标、论文代码阅读。
每项附一个真实文件路径；未完成或受阻的项明确标记。

## 实验一：真实压缩基线
问题 / 测试集及哈希清单 / 模型版本 / 设置 / CSV / RD 图 / 结论 / 限制。

## 实验二：单变量实验
预先假设 / 唯一变量 / 固定条件 / 每个种子结果 / 观察 / 替代解释。

## 尚未解决的问题
写两个具体问题，并给出已尝试的排查。

## 下一步与指导需求
说明感兴趣的方向、可投入时间、希望得到的基础任务或反馈。
'''
    path=OUT/'L36_final_report.md'; path.write_text(template,encoding='utf-8'); print(path)
    print('Template generated. Fill using your real results; generation does not mark the course complete.')

if __name__ == "__main__":
    lesson36()
