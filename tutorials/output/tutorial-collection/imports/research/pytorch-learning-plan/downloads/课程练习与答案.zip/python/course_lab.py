"""Shared teaching utilities. Synthetic images are labelled; no fake codec fallback."""
from pathlib import Path
import argparse, csv, hashlib, io, json, math, platform, statistics, struct, sys, time
import numpy as np
from PIL import Image
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, TensorDataset

torch.set_num_threads(2)
OUT = Path(__file__).resolve().parent / 'outputs'
OUT.mkdir(exist_ok=True)

def seed(value=42):
    torch.manual_seed(value)
    np.random.seed(value)

def emit(name, value):
    path=OUT/name
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(path)
    return path

def stripes(n=64, noise=.15, random_seed=42):
    g=torch.Generator().manual_seed(random_seed)
    labels=torch.arange(n)%2
    x=torch.zeros(n,1,16,16)
    x[labels==0,0,::2,:]=1
    x[labels==1,0,:,::2]=1
    x=(x+noise*torch.randn(x.shape,generator=g)).clamp(0,1)
    return x,labels.long()

def picture(size=32, random_seed=42):
    # Synthetic calibration image, not a natural-image benchmark.
    g=torch.Generator().manual_seed(random_seed)
    v=torch.linspace(0,1,size)
    yy,xx=torch.meshgrid(v,v,indexing='ij')
    rgb=torch.stack([xx,yy,.5+.4*torch.sin(xx*12)*torch.cos(yy*9)])
    return (rgb+.02*torch.randn(rgb.shape,generator=g)).clamp(0,1).unsqueeze(0)

def pil_tensor(img):
    a=np.asarray(img.convert('RGB'),dtype=np.float32)/255
    return torch.from_numpy(a.copy()).permute(2,0,1).unsqueeze(0)

def to_image(x):
    a=x.detach().cpu().squeeze(0).clamp(0,1).permute(1,2,0).numpy()
    return Image.fromarray(np.round(a*255).astype(np.uint8))

def psnr(x,y):
    mse=float(torch.mean((x.double()-y.double())**2))
    return math.inf if mse==0 else -10*math.log10(mse)

def bpp(byte_count,h,w):
    if byte_count<0 or h<=0 or w<=0: raise ValueError('invalid byte count or dimensions')
    return 8*byte_count/(h*w)

def csv_write(name, rows):
    if not rows: raise ValueError('empty results')
    path=OUT/name
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(path)
    return path

def classifier(cnn=False):
    if cnn:
        return nn.Sequential(nn.Conv2d(1,4,3,padding=1),nn.ReLU(),nn.Flatten(),nn.Linear(4*256,2))
    return nn.Sequential(nn.Flatten(),nn.Linear(256,16),nn.ReLU(),nn.Linear(16,2))

def fit_classifier(model, epochs=6, lr=.08):
    x,y=stripes(); loader=DataLoader(TensorDataset(x,y),batch_size=16,shuffle=True)
    opt=torch.optim.SGD(model.parameters(),lr=lr)
    history=[]
    for _ in range(epochs):
        model.train(); total=0.
        for xb,yb in loader:
            loss=F.cross_entropy(model(xb),yb)
            assert torch.isfinite(loss)
            opt.zero_grad(); loss.backward(); opt.step()
            total+=float(loss.detach())*len(xb)
        history.append(total/len(x))
    return history

def evaluate(model,x,y):
    model.eval()
    with torch.inference_mode():
        logits=model(x)
        return dict(loss=float(F.cross_entropy(logits,y)), accuracy=float((logits.argmax(1)==y).float().mean()))

class Autoencoder(nn.Module):
    def __init__(self, channels=8):
        super().__init__()
        self.encoder=nn.Sequential(nn.Conv2d(3,8,3,2,1),nn.ReLU(),nn.Conv2d(8,channels,3,2,1))
        self.decoder=nn.Sequential(nn.Conv2d(channels,8,3,padding=1),nn.ReLU(),nn.Conv2d(8,3,3,padding=1),nn.Sigmoid())
    def forward(self,x):
        y=self.encoder(x)
        return self.decoder(F.interpolate(y,size=x.shape[-2:],mode='bilinear',align_corners=False))

def fit_autoencoder(channels=8, steps=60, random_seed=42):
    seed(random_seed); model=Autoencoder(channels); x=picture()
    opt=torch.optim.Adam(model.parameters(),lr=.01)
    initial=float(F.mse_loss(model(x),x).detach())
    old=[p.detach().clone() for p in model.parameters()]
    for _ in range(steps):
        loss=F.mse_loss(model(x),x); assert torch.isfinite(loss)
        opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    with torch.inference_mode(): out=model(x); final=float(F.mse_loss(out,x))
    assert final<initial, (initial,final)
    assert any(not torch.equal(p,q) for p,q in zip(old,model.parameters()))
    return model,dict(initial_mse=initial,final_mse=final,steps=steps,seed=random_seed,synthetic=True,train_test_overlap=True)

def jpeg_row(img,quality,name='synthetic'):
    buf=io.BytesIO(); img.save(buf,format='JPEG',quality=quality,subsampling=0)
    reconstructed=Image.open(io.BytesIO(buf.getvalue())).convert('RGB')
    x,y=pil_tensor(img),pil_tensor(reconstructed)
    return dict(image=name,model='jpeg',quality=quality,width=img.width,height=img.height,
      file_bytes=len(buf.getvalue()),payload_bytes='',file_bpp=bpp(len(buf.getvalue()),img.height,img.width),
      payload_bpp='',estimated_bpp='',psnr=psnr(x,y),side_bytes='',encode_seconds='',decode_seconds='')

def read_csv(path):
    with Path(path).open(encoding='utf-8',newline='') as f: return list(csv.DictReader(f))

def rd_svg(rows,path):
    from html import escape
    groups={}
    for r in rows:
        k=(r['model'],str(r['quality']))
        groups.setdefault(k,[]).append((float(r['file_bpp']),float(r['psnr'])))
    points={}
    for (model,q),vals in groups.items():
        points.setdefault(model,[]).append((statistics.mean(v[0] for v in vals),statistics.mean(v[1] for v in vals),q))
    flat=[v for values in points.values() for v in values]
    if not flat or not all(math.isfinite(a) and math.isfinite(b) for a,b,_ in flat): raise ValueError('finite measured results required')
    xmin=0; xmax=max(v[0] for v in flat)*1.1 or 1
    ymin=min(v[1] for v in flat)-2; ymax=max(v[1] for v in flat)+2
    sx=lambda x:65+x/xmax*530; sy=lambda y:285-(y-ymin)/(ymax-ymin)*225
    chunks=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 350"><rect width="760" height="350" fill="#fffdf7"/>',
      '<g font-family="sans-serif" font-size="12" fill="#1e2c2a"><path d="M65 45V285H595" fill="none" stroke="#1e2c2a"/>',
      '<text x="225" y="332">Full-file bpp (mean per image)</text><text x="12" y="25">PSNR / dB</text>']
    for i in range(5):
        x=xmax*i/4; y=ymin+(ymax-ymin)*i/4
        chunks += [f'<text x="{sx(x):.1f}" y="306">{x:.2f}</text>',f'<text x="15" y="{sy(y):.1f}">{y:.1f}</text>']
    for i,(model,values) in enumerate(points.items()):
        c=['#b94631','#315b6f','#446c5c'][i%3]; values.sort()
        coords=' '.join(f'{sx(x):.2f},{sy(y):.2f}' for x,y,q in values)
        chunks.append(f'<polyline points="{coords}" fill="none" stroke="{c}" stroke-width="2"/>')
        chunks.append(f'<text x="610" y="{65+i*25}" fill="{c}">{escape(model)}</text>')
        for x,y,q in values: chunks.append(f'<circle cx="{sx(x):.2f}" cy="{sy(y):.2f}" r="4" fill="{c}"/>')
    chunks.append('</g></svg>'); Path(path).write_text(''.join(chunks),encoding='utf-8')
    print(path)

MAGIC=b'LICCOURSE1\n'
def pack_stream(path,meta,strings):
    header=dict(meta); header['stream_lengths']=[[len(s) for s in group] for group in strings]
    blob=json.dumps(header,separators=(',',':')).encode('utf-8')
    Path(path).write_bytes(MAGIC+struct.pack('>I',len(blob))+blob+b''.join(s for group in strings for s in group))

def unpack_stream(path):
    data=Path(path).read_bytes()
    if not data.startswith(MAGIC): raise ValueError('not a course bitstream')
    pos=len(MAGIC)
    if len(data)<pos+4: raise ValueError('truncated header')
    length=struct.unpack('>I',data[pos:pos+4])[0]; pos+=4
    if length>1_000_000 or pos+length>len(data): raise ValueError('invalid header length')
    meta=json.loads(data[pos:pos+length]); pos+=length; strings=[]
    for lengths in meta['stream_lengths']:
        group=[]
        for size in lengths:
            if not isinstance(size,int) or size<0 or pos+size>len(data): raise ValueError('truncated stream')
            group.append(data[pos:pos+size]); pos+=size
        strings.append(group)
    if pos!=len(data): raise ValueError('unexpected trailing bytes')
    return meta,strings

def load_codec(name,quality):
    if platform.system()!='Linux': raise RuntimeError('Use the separate WSL Linux environment for CompressAI; see environment.md')
    from compressai.zoo import bmshj2018_factorized,bmshj2018_hyperprior
    choices={'factorized':bmshj2018_factorized,'hyperprior':bmshj2018_hyperprior}
    model=choices[name](quality=quality,pretrained=True).eval().cpu()
    model.update(force=True)
    return model

def real_encode(img,name,quality,path,model=None):
    model=model or load_codec(name,quality)
    x=pil_tensor(img); h,w=x.shape[-2:]; padded=F.pad(x,(0,(-w)%64,0,(-h)%64))
    with torch.inference_mode():
        start=time.perf_counter(); enc=model.compress(padded); encoding=time.perf_counter()-start
        forward=model(padded)
        estimated=sum(float(-torch.log2(p.clamp_min(1e-12)).sum()) for p in forward['likelihoods'].values())/(h*w)
    pack_stream(path,dict(model=name,quality=quality,height=h,width=w,shape=list(enc['shape'])),enc['strings'])
    meta,streams=unpack_stream(path)
    with torch.inference_mode():
        start=time.perf_counter(); decoded=model.decompress(streams,meta['shape'])['x_hat'][...,:h,:w].clamp(0,1); decoding=time.perf_counter()-start
        reference=model.decompress(enc['strings'],enc['shape'])['x_hat'][...,:h,:w].clamp(0,1)
    assert decoded.shape==x.shape and torch.equal(decoded,reference)
    to_image(decoded).save(Path(path).with_suffix('.reconstruction.png'))
    payload=sum(len(s) for group in streams for s in group)
    side=sum(len(s) for group in streams[1:] for s in group)
    return dict(image='',model=name,quality=quality,width=w,height=h,file_bytes=Path(path).stat().st_size,
      payload_bytes=payload,file_bpp=bpp(Path(path).stat().st_size,h,w),payload_bpp=bpp(payload,h,w),
      estimated_bpp=estimated,psnr=psnr(x,decoded),side_bytes=side,encode_seconds=encoding,decode_seconds=decoding)

def benchmark(folder,include_hyper=False):
    files=sorted(p for p in Path(folder).iterdir() if p.suffix.lower() in {'.png','.jpg','.jpeg'})
    if len(files)<5: raise ValueError('Provide at least five fixed, distinct test images')
    hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files]
    if len(set(hashes))!=len(hashes): raise ValueError('duplicate image files')
    emit('test_manifest.json',[dict(file=p.name,sha256=h) for p,h in zip(files,hashes)])
    rows=[]; models=['factorized']+(['hyperprior'] if include_hyper else [])
    for p in files:
        img=Image.open(p).convert('RGB')
        for q in [20,50,85]: rows.append(jpeg_row(img,q,p.name))
    for name in models:
        for q in [1,3,5]:
            model=load_codec(name,q)
            for i,p in enumerate(files):
                row=real_encode(Image.open(p).convert('RGB'),name,q,OUT/f'{i}_{p.stem}_{name}_q{q}.lic',model)
                row['image']=p.name; rows.append(row)
                csv_write('benchmark_partial.csv',rows)
    path=csv_write('benchmark.csv',rows)
    import importlib.metadata as im
    emit('benchmark_environment.json',dict(python=sys.version,torch=torch.__version__,compressai=im.version('compressai'),
      platform=platform.platform(),device='cpu',psnr='mean per image RGB range 0..1',bpp='full file / original pixels',
      padding='right/bottom zero to multiples of 64',jpeg_subsampling=0,models_shared=True,
      timing='compress/decompress only, excludes model load, file IO, forward rate estimation; single samples, not a latency benchmark'))
    return path

def cli():
    p=argparse.ArgumentParser()
    p.add_argument('--image'); p.add_argument('--images'); p.add_argument('--results'); p.add_argument('--bitstream')
    p.add_argument('--project',default=str(Path(__file__).resolve().parents[2]/'learned-image-compression-study'))
    p.add_argument('--hpcm',default=str(Path(__file__).resolve().parents[2]/'LIC-HPCM'))
    p.add_argument('--quality',type=int,default=1); p.add_argument('--model',choices=['factorized','hyperprior'],default='factorized')
    p.add_argument('--self-test',action='store_true'); p.add_argument('--cuda',action='store_true')
    return p.parse_args()
