"""Download the six official CompressAI checkpoints used in L22/L27.

Run with the Windows Python interpreter if WSL networking is slow. In WSL,
set TORCH_HOME to this project's python/weights before running codec lessons.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import urllib.request

TARGET = Path(__file__).resolve().parent / 'weights' / 'hub' / 'checkpoints'
ROOT = 'https://compressai.s3.amazonaws.com/models/v1/'
FILES = [
    'bmshj2018-factorized-prior-1-446d5c7f.pth.tar',
    'bmshj2018-factorized-prior-3-5c6f152b.pth.tar',
    'bmshj2018-factorized-prior-5-866ba797.pth.tar',
    'bmshj2018-hyperprior-1-7eb97409.pth.tar',
    'bmshj2018-hyperprior-3-6d87be32.pth.tar',
    'bmshj2018-hyperprior-5-f8b614e1.pth.tar',
]

def one(name):
    path = TARGET / name
    expected = name.removesuffix('.pth.tar').split('-')[-1]
    def digest(p):
        h = hashlib.sha256()
        with p.open('rb') as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(part)
        return h.hexdigest()
    if path.exists() and digest(path).startswith(expected):
        return f'{name}: cached, SHA256 prefix verified'
    temp = path.with_name(name + '.part')
    try:
        urllib.request.urlretrieve(ROOT + name, temp)
        if not digest(temp).startswith(expected):
            raise ValueError(f'checkpoint SHA256 prefix mismatch: {name}')
        temp.replace(path)
        return f'{name}: downloaded, SHA256 prefix verified ({path.stat().st_size} bytes)'
    finally:
        temp.unlink(missing_ok=True)

if __name__ == '__main__':
    TARGET.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(one, FILES):
            print(result, flush=True)
