"""Download five fixed Kodak evaluation images, never used for course training."""
from pathlib import Path
import hashlib,json,urllib.request
from PIL import Image

root=Path(__file__).resolve().parent/'test-images'
root.mkdir(exist_ok=True)
manifest=[]
for i in range(1,6):
    name=f'kodim{i:02}.png'; path=root/name
    url=f'https://r0k.us/graphics/kodak/kodak/{name}'
    if not path.exists():
        with urllib.request.urlopen(url,timeout=60) as r: data=r.read()
        temporary=path.with_suffix('.download'); temporary.write_bytes(data)
        with Image.open(temporary) as image: image.verify()
        temporary.replace(path)
    with Image.open(path) as image:
        if set(image.size)!={512,768}: raise ValueError(f'Unexpected dimensions: {path}: {image.size}')
        size=image.size
    manifest.append(dict(file=name,url=url,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),size=size,usage='test only'))
    print(name,size)
(root/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
