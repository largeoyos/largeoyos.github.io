from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson02():
    """把 HWC 数组转为 NCHW，计算每通道均值，并断言范围在 0～1。"""
    hwc = torch.arange(16*20*3).reshape(16,20,3) % 256
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson02()
