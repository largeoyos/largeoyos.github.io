from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson03():
    """补全四步训练循环，记录初始和最终损失，验证参数发生变化。"""
    x = torch.linspace(-1,1,50).unsqueeze(1)
    y = 2*x+1
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson03()
