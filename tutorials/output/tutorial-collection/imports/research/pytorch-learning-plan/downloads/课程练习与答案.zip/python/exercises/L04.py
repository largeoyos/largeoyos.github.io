from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson04():
    """构建 TensorDataset 和 DataLoader，统计遍历样本总数并验证末批大小。"""
    x, y = stripes(10)
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson04()
