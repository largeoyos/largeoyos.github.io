from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson07():
    """实现输出尺寸计算函数，对照两层卷积实际 shape。"""
    cases = [(32,3,1,2),(31,5,2,2),(17,3,0,1)]
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson07()
