from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson12():
    """实现均匀量化，比较步长 0.1、0.5、1.0 的误差和符号数。"""
    y = torch.linspace(-2,2,101)
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson12()
