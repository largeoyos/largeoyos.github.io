from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson14():
    """实现 entropy 和 cross_entropy，验证两者差非负且 q=p 时相等。"""
    p, q = [.75,.25], [.5,.5]
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson14()
