from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson15():
    """计算同一预测下三种 lambda 的总损失，分别输出 R、D、L。"""
    likelihood = torch.tensor([.5,.25,.125,.125])
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson15()
