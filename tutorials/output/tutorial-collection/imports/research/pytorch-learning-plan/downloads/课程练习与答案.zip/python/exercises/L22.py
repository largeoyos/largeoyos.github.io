from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson22():
    """运行基准入口，对五张图片与两种编码器生成至少 30 行结果，保留完整文件 bpp。"""
    seed()
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson22()
