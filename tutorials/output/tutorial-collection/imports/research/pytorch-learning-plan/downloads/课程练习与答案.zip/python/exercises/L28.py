from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson28():
    """写一个依赖检查器，验证有效顺序，并让未来依赖案例触发错误。"""
    seed()
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson28()
