from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson29():
    """手写缩放点积注意力，验证权重和为 1、因果 mask 后未来权重为 0。"""
    seed()
    q, k, v = torch.randn(3,4), torch.randn(3,4), torch.randn(3,2)
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson29()
