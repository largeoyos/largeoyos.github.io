from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from course_lab import *

def lesson34():
    """生成研究线比较表，再用四帧复杂度做一次简单的比例码率分配。"""
    complexity, budget = [4,2,1,1], 4000
    # TODO: 按课程练习实现，再运行验收断言。
    raise NotImplementedError("请先完成本课练习；分步提示与答案在网页中。")

if __name__ == "__main__":
    lesson34()
