#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv ../.venv-linux
../.venv-linux/bin/python -m pip install --upgrade pip
../.venv-linux/bin/python -m pip install torch==2.11.0 torchvision==0.26.0 --index-url https://download.pytorch.org/whl/cpu
../.venv-linux/bin/python -m pip install compressai==1.2.8 'numpy<2.3' Pillow
../.venv-linux/bin/python -m pip freeze > ../downloads/linux-environment-lock.txt
../.venv-linux/bin/python -c 'import torch, compressai; print(torch.__version__, compressai.__version__)'
