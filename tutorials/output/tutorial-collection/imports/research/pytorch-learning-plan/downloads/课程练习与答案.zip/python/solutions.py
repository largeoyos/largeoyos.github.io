"""Each lesson function is extracted by build.py into a downloadable answer."""
from course_lab import *

def lesson01():
    def summarize(values):
        if not values: raise ValueError('values must not be empty')
        mean=sum(values)/len(values)
        return dict(count=len(values),total=sum(values),mean=mean,above_mean=[x for x in values if x>mean])
    result=summarize([30,45,20,60,25]); assert result['mean']==36
    try: summarize([])
    except ValueError: pass
    else: raise AssertionError('empty input not rejected')
    path=emit('L01.json',result)
    assert json.loads(path.read_text(encoding='utf-8'))==result
    print(result)

def lesson02():
    hwc=torch.arange(16*20*3,dtype=torch.int64).reshape(16,20,3)%256
    x=hwc.float().permute(2,0,1).unsqueeze(0)/255
    assert x.shape==(1,3,16,20) and 0<=x.min()<=x.max()<=1
    means=x.mean(dim=(0,2,3)); print(x.shape,means)
    restored=(x.squeeze(0).permute(1,2,0)*255).round().long()
    assert torch.equal(restored,hwc)

def lesson03():
    seed(); x=torch.linspace(-1,1,50).unsqueeze(1); y=2*x+1
    model=nn.Linear(1,1); opt=torch.optim.SGD(model.parameters(),lr=.1)
    before=[p.detach().clone() for p in model.parameters()]; history=[]
    for _ in range(150):
        loss=F.mse_loss(model(x),y); assert torch.isfinite(loss)
        opt.zero_grad(); loss.backward(); opt.step(); history.append(loss.item())
    assert history[-1]<history[0] and abs(model.weight.item()-2)<.02
    assert any(not torch.equal(a,b) for a,b in zip(before,model.parameters()))
    print('w,b,initial,final:',model.weight.item(),model.bias.item(),history[0],history[-1])
    emit('L03.json',history)

def lesson04():
    x,y=stripes(10); loader=DataLoader(TensorDataset(x,y),batch_size=4,shuffle=False)
    sizes=[]
    for xb,yb in loader:
        print(xb.shape,yb.shape,yb.dtype); sizes.append(len(xb))
    assert sizes==[4,4,2] and sum(sizes)==10

def lesson05():
    seed(); model=classifier(); history=fit_classifier(model)
    assert history[-1]<history[0]; print('loss:',history)
    print('parameters:',sum(p.numel() for p in model.parameters()))
    emit('L05.json',history)

def lesson06():
    seed(); model=classifier(); fit_classifier(model)
    x,y=stripes(random_seed=99); scores=evaluate(model,x,y)
    path=OUT/'L06.pt'; torch.save(model.state_dict(),path)
    restored=classifier(); restored.load_state_dict(torch.load(path,map_location='cpu',weights_only=True)); restored.eval()
    with torch.inference_mode(): assert torch.allclose(model(x),restored(x))
    print(scores,'reload checked'); emit('L06.json',scores)

def lesson07():
    def output_size(h,k,p,s,d=1): return (h+2*p-d*(k-1)-1)//s+1
    for h,k,p,s in [(32,3,1,2),(31,5,2,2),(17,3,0,1)]:
        layer=nn.Conv2d(3,8,k,stride=s,padding=p)
        y=layer(torch.zeros(1,3,h,h)); expected=output_size(h,k,p,s)
        assert y.shape[-1]==expected
        assert sum(x.numel() for x in layer.parameters())==8*(3*k*k+1)
        print(h,'->',y.shape,'parameters',8*(3*k*k+1))

def lesson08():
    seed(); model=classifier(cnn=True); history=fit_classifier(model)
    clean=evaluate(model,*stripes(random_seed=98)); noisy=evaluate(model,*stripes(noise=.8,random_seed=99))
    emit('L08.json',dict(synthetic=True,train_loss=history,validation=clean,noisy_validation=noisy))
    print(clean,noisy)

def lesson09():
    args=cli(); img=Image.open(args.image).convert('RGB') if args.image else to_image(picture(96))
    name=Path(args.image).name if args.image else 'synthetic-demo'
    rows=[jpeg_row(img,q,name) for q in [20,50,85]]
    for r in rows: print(r['quality'],r['file_bpp'],r['psnr'])
    assert psnr(pil_tensor(img),pil_tensor(img))==math.inf
    csv_write('L09_jpeg.csv',rows)
    to_image(picture(96)).save(OUT/'synthetic-demo.png')

def lesson10():
    seed(); model=Autoencoder(); x=picture()
    for layer in model.encoder:
        x=layer(x); print(type(layer).__name__,tuple(x.shape))
    assert x.shape==(1,8,8,8)
    out=model(picture()); assert out.shape==picture().shape
    print('input/latent values:',picture().numel(),x.numel())

def lesson11():
    model,record=fit_autoencoder(); x=picture()
    with torch.inference_mode(): y=model(x)
    to_image(x).save(OUT/'L11_original.png'); to_image(y).save(OUT/'L11_reconstruction.png')
    to_image((x-y).abs()*4).save(OUT/'L11_error_x4.png')
    torch.save(model.state_dict(),OUT/'L11.pt'); emit('L11.json',record); print(record)

def lesson12():
    y=torch.linspace(-2,2,101)
    for step in [.1,.5,1.]:
        q=torch.round(y/step); reconstructed=q*step; error=(y-reconstructed).abs()
        assert error.max()<=step/2+1e-6
        print('step,max_error,symbols:',step,float(error.max()),len(q.unique()))
    y=torch.tensor([.37],requires_grad=True)
    ste=y+(y.round()-y).detach(); ste.sum().backward(); assert y.grad.item()==1

def lesson13():
    probabilities=[.5,.25,.125,.125]
    bits=[-math.log2(p) for p in probabilities]
    cdf=lambda x:.5*(1+math.erf(x/math.sqrt(2)))
    mass=cdf(.5)-cdf(-.5)
    assert bits==[1,2,3,3] and 0<mass<1
    print('bits:',bits,'standard normal mass [-.5,.5]:',mass)

def lesson14():
    def cross_entropy(p,q):
        return sum(-a*math.log2(b) if b>0 else math.inf for a,b in zip(p,q) if a>0)
    p=[.75,.25]; h=cross_entropy(p,p); cross=cross_entropy(p,[.5,.5])
    assert abs(h-.811278124459)<1e-8 and cross>=h
    print('entropy,cross_entropy,KL:',h,cross,cross-h)

def lesson15():
    likelihood=torch.tensor([.5,.25,.125,.125]).reshape(1,1,2,2)
    rate=-likelihood.log2().sum()/4; mse=torch.tensor(.01)
    for lam in [1,10,100]: print('R,D,L:',rate.item(),mse.item(),(rate+lam*mse).item())
    assert rate.item()==2.25
    print('scaled MSE:',float(mse*255**2),'not the same lambda convention')

def lesson16():
    args=cli(); root=Path(args.project)/'src'/'lic_study'
    for filename in ['model.py','train_toy.py','metrics.py']:
        p=root/filename
        if not p.exists(): raise FileNotFoundError(f'{p}: pass --project with the local study project')
        print('\n',p)
        for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
            if any(k in line for k in ['def forward','def likelihood','def rate_distortion','def estimated_bpp','rd_lambda']): print(i,line.strip())

def lesson17():
    _,record=fit_autoencoder(steps=30)
    print('single-image diagnostic, NOT generalization:',record); emit('L17.json',record)

def lesson18():
    def digest(data): return hashlib.sha256(data).hexdigest()
    train={'a.png':digest(b'image A'),'b.png':digest(b'image B')}
    test={'renamed.png':digest(b'image A')}
    overlap=set(train.values())&set(test.values()); assert len(overlap)==1
    print('deliberate leakage detected:',overlap)
    test={'c.png':digest(b'image C')}; assert not set(train.values())&set(test.values())
    emit('L18_manifest_example.json',dict(synthetic_fixture=True,train=train,test=test,seed=42,range='0..1',device='cpu'))

def lesson19():
    import importlib.util
    report=dict(executable=sys.executable,system=platform.system(),python=sys.version,torch=torch.__version__,
      cuda=torch.cuda.is_available(),compressai_installed=importlib.util.find_spec('compressai') is not None)
    emit('L19_environment.json',report); print(report)
    print('Environment inspection only; does not install WSL or packages.')

def lesson20():
    args=cli()
    if not args.image: raise ValueError('Use --image /path/to/photo.png inside the Linux environment')
    img=Image.open(args.image).convert('RGB')
    row=real_encode(img,args.model,args.quality,OUT/'L20.lic'); row['image']=Path(args.image).name
    csv_write('L20.csv',[row]); print(row)

def lesson21():
    args=cli()
    if args.self_test:
        path=OUT/'L21_serializer_fixture.lic'
        pack_stream(path,dict(height=100,width=100),[[b'abc'],[b'xy']])
        meta,streams=unpack_stream(path); assert streams==[[b'abc'],[b'xy']]
        print('SERIALIZER TEST ONLY: arbitrary bytes, NOT an entropy coding result')
    else:
        if not args.bitstream: raise ValueError('Pass --bitstream outputs/L20.lic')
        path=Path(args.bitstream); meta,streams=unpack_stream(path)
        model=load_codec(meta['model'],int(meta['quality']))
        with torch.inference_mode():
            decoded=model.decompress(streams,meta['shape'])['x_hat'][...,:meta['height'],:meta['width']].clamp(0,1)
        assert tuple(decoded.shape)==(1,3,meta['height'],meta['width'])
        reconstructed=OUT/'L21_decoded.png'
        to_image(decoded).save(reconstructed)
        print('Decoded from stored bytes in a fresh process:',reconstructed,tuple(decoded.shape))
    payload=sum(len(s) for group in streams for s in group); total=path.stat().st_size
    assert total>payload
    print(dict(payload_bytes=payload,header_bytes=total-payload,payload_bpp=bpp(payload,meta['height'],meta['width']),file_bpp=bpp(total,meta['height'],meta['width'])))

def lesson22():
    args=cli()
    if not args.images: raise ValueError('Pass --images folder containing at least 5 fixed test images in Linux')
    print(benchmark(args.images))

def lesson23():
    args=cli()
    if not args.results: raise ValueError('Pass --results outputs/benchmark.csv, or explicitly use L09_jpeg.csv for a synthetic teaching plot')
    rows=read_csv(args.results); rd_svg(rows,OUT/'L23_RD.svg')
    print('source:',args.results,'Do not present synthetic-image plots as natural-image benchmark results.')

def lesson24():
    args=cli()
    if not args.results: raise ValueError('Pass --results with an actual CSV')
    rows=read_csv(args.results); assert rows
    text='# 第一份压缩实验报告\n\n数据来源：'+str(Path(args.results).resolve())+'\n\n'
    text+='原始记录数：'+str(len(rows))+'\n\n'
    text+='## 问题与设置\n请根据实际运行填写图片来源、模型、版本、设备、预处理、统计口径。\n\n'
    text+='## 两条观察\n逐条指向 CSV 或图片；区分观察与假设。\n\n## 限制\n说明样本量、速度计量和环境阻塞。\n\n## 下一步\n写一个可以用控制变量实验回答的问题。\n'
    path=OUT/'L24_report.md'; path.write_text(text,encoding='utf-8'); print(path)

def lesson25():
    p=torch.tensor([.5,.25,.125,.125]); symbols=torch.tensor([0,1,1,2,3])
    lengths=-p[symbols].log2(); assert float(lengths.sum())==11
    print('ideal factorized lengths:',lengths.tolist(),'total',float(lengths.sum()))
    print('No actual bitstream produced; model ignores dependencies.')

def lesson26():
    original=1000; conditioned=700
    rows=[]
    for side in [0,120,300,400]:
        total=conditioned+side; rows.append(dict(side=side,total=total,saving=original-total))
    assert rows[1]['saving']==180 and rows[2]['saving']==0
    print(rows)

def lesson27():
    args=cli()
    if not args.images: raise ValueError('Pass --images with the same fixed test folder in Linux')
    path=benchmark(args.images,include_hyper=True)
    rows=read_csv(path); rd_svg(rows,OUT/'L27_RD.svg')
    for r in rows:
        if r['model']=='hyperprior': print(r['image'],r['quality'],'side bytes:',r['side_bytes'])

def lesson28():
    def check(steps):
        known={'z'}
        for name,deps in steps:
            if not set(deps)<=known: raise ValueError(f'{name}: future dependency {set(deps)-known}')
            known.add(name)
        return known
    print(check([('y1',['z']),('y2',['z','y1'])]))
    try: check([('y1',['y2']),('y2',['z'])])
    except ValueError as e: print('correctly rejected:',e)
    else: raise AssertionError('leakage not detected')

def lesson29():
    seed(); q=torch.randn(3,4); k=torch.randn(3,4); v=torch.randn(3,2)
    scores=q@k.T/math.sqrt(q.shape[-1])
    mask=torch.triu(torch.ones(3,3,dtype=torch.bool),diagonal=1)
    weights=scores.masked_fill(mask,-torch.inf).softmax(dim=-1)
    out=weights@v
    assert out.shape==(3,2) and torch.allclose(weights.sum(-1),torch.ones(3))
    assert torch.all(weights[mask]==0)
    print('weights:',weights,'output:',out)

def lesson30():
    args=cli(); root=Path(args.hpcm); p=root/'src'/'models'/'HPCM_Base.py'
    if not p.exists(): raise FileNotFoundError(f'{p}: use --hpcm with repository path')
    import subprocess
    result=subprocess.run(['git','-C',str(root),'rev-parse','HEAD'],capture_output=True,text=True)
    print('commit:',result.stdout.strip() or 'unavailable')
    for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        if any(k in line for k in ['def forward','context_next','y_hat_so_far','self.g_a(x)','self.h_a(y)']): print(i,line.strip())
    print('Static code reading only; original model has not been executed.')

def lesson31():
    x=torch.tensor([-3.,-.9,-.1,0.,.26,.9,3.])
    for bits in [4,8,12]:
        qmax=2**(bits-1)-1; scale=1/qmax # calibrated range [-1,1], deliberate outliers
        q=(x/scale).round().clamp(-qmax,qmax); restored=q*scale
        print(bits,'MSE:',float(F.mse_loss(restored,x)),'saturated:',float((x.abs()>1).float().mean()))
    print('Fake quantization simulation; NOT an integer kernel speed benchmark.')

def lesson32():
    limit=2**31-1
    for count in [1,100,200000]:
        upper=count*128*128+100+64
        print('K,bound,fits_int32:',count,upper,upper<=limit)
    assert 200000*128*128>limit
    print('negative rounding: floor division',-3//2,'ties-to-even round',round(-3/2))

def lesson33():
    args=cli(); device='cuda' if args.cuda else 'cpu'
    if device=='cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA requested but unavailable')
    seed(); model=classifier(cnn=True).to(device).eval(); x=stripes(1)[0].to(device)
    sync=lambda: torch.cuda.synchronize() if device=='cuda' else None
    times=[]
    with torch.inference_mode():
        for _ in range(5): model(x)
        for _ in range(20):
            sync(); start=time.perf_counter(); model(x); sync(); times.append(time.perf_counter()-start)
    record=dict(device=device,shape=list(x.shape),parameters=sum(p.numel() for p in model.parameters()),
      median_seconds=statistics.median(times),min_seconds=min(times),max_seconds=max(times),scope='forward only; no codec or I/O',threads=torch.get_num_threads())
    print(record); emit('L33.json',record)

def lesson34():
    complexity=[4,2,1,1]; budget=4000
    bits=[budget*c//sum(complexity) for c in complexity]; bits[-1]+=budget-sum(bits)
    assert sum(bits)==budget
    print('heuristic allocation, NOT optimal rate control:',bits)
    rows=[dict(object='image',redundancy='spatial',metric='RGB PSNR / bpp'),
      dict(object='video',redundancy='temporal + spatial',metric='quality / bitrate / FPS'),
      dict(object='point cloud',redundancy='3D occupancy',metric='geometry distortion / bits per point'),
      dict(object='3D scene',redundancy='shared scene',metric='rendering quality / storage')]
    csv_write('L34_research_map.csv',rows)

def lesson35():
    rows=[]
    for random_seed in [11,22,33]:
        for channels in [4,8]:
            model,record=fit_autoencoder(channels=channels,steps=40,random_seed=random_seed)
            test=picture(random_seed=99)
            model.eval()
            with torch.inference_mode():
                for _ in range(5): model(test)
                timings=[]
                for _ in range(20):
                    t0=time.perf_counter()
                    pred=model(test)
                    timings.append((time.perf_counter()-t0)*1000)
                error=float(F.mse_loss(pred,test))
            rows.append(dict(channels=channels,seed=random_seed,steps=40,train_mse=record['final_mse'],
              test_mse=error,parameters=sum(p.numel() for p in model.parameters()),
              forward_median_ms=statistics.median(timings),device='cpu',warmup=5,timed_runs=20,synthetic=True))
    csv_write('L35_ablation.csv',rows)
    print('Different synthetic noise realization; not a diverse natural-image generalization benchmark.')

def lesson36():
    template='''# 十二周学习总结

## 能力与证据
分别列出：训练循环、保存加载、图像重建、真实码流、评价指标、论文代码阅读。
每项附一个真实文件路径；未完成或受阻的项明确标记。

## 实验一：真实压缩基线
问题 / 测试集及哈希清单 / 模型版本 / 设置 / CSV / RD 图 / 结论 / 限制。

## 实验二：单变量实验
预先假设 / 唯一变量 / 固定条件 / 每个种子结果 / 观察 / 替代解释。

## 尚未解决的问题
写两个具体问题，并给出已尝试的排查。

## 下一步与指导需求
说明感兴趣的方向、可投入时间、希望得到的基础任务或反馈。
'''
    path=OUT/'L36_final_report.md'; path.write_text(template,encoding='utf-8'); print(path)
    print('Template generated. Fill using your real results; generation does not mark the course complete.')
