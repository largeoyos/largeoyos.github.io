#!/usr/bin/env bash
set -euo pipefail
cd /mnt/e/Projects/research/pytorch-learning-plan
export TORCH_HOME=/mnt/e/Projects/research/pytorch-learning-plan/python/weights
PY=.venv-linux/bin/python
$PY python/answers/L21.py --bitstream python/outputs/L20.lic
$PY python/answers/L22.py --images python/test-images
$PY python/answers/L23.py --results python/outputs/benchmark.csv
$PY python/answers/L24.py --results python/outputs/benchmark.csv
$PY python/answers/L27.py --images python/test-images
$PY python/answers/L23.py --results python/outputs/benchmark.csv
echo 'WSL real bitstream, five-image JPEG/factorized/hyperprior benchmark and RD plot passed.'
