#!/usr/bin/env bash
# Build both official DCVC-RT extensions inside the dedicated environment.
# Usage: bash apptainer/build_dcvc_rt.sh [DCVC_REPO_ROOT] [ENV_PREFIX]
set -euo pipefail

if [[ ${1:-} == --help ]]; then
    echo "Usage: bash apptainer/build_dcvc_rt.sh [DCVC_REPO_ROOT] [ENV_PREFIX]"
    echo "Defaults: \$HOME/video-code-lab/DCVC and \$HOME/envs/dcvc-rt"
    exit 0
fi
task_repo="${1:-$HOME/video-code-lab/DCVC}"
task_prefix="${2:-$HOME/envs/dcvc-rt}"
task_script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
task_conda="${CONDA_EXE:-}"
if [[ -z "$task_conda" ]]; then
    task_conda=$(type -P conda || true)
fi
if [[ ! -x "$task_conda" || ! -f "$task_prefix/conda-meta/history" ]]; then
    echo "Run setup_dcvc_rt.sh first from a Conda-enabled shell." >&2
    exit 2
fi
if [[ "$task_repo" != /* || "$task_prefix" != "$HOME"/envs/dcvc-rt* || "$task_prefix" == *".."* ]]; then
    echo "Use an absolute repository path and the dedicated dcvc-rt environment." >&2
    exit 2
fi
set +u
eval "$("$task_conda" shell.bash hook)"
conda activate "$task_prefix"
set -u
export CUDA_HOME="$task_prefix"
export MAX_JOBS=4
export TORCH_CUDA_ARCH_LIST="8.0"
python "$task_script_dir/check_environment.py" --strict

if [[ ! -e "$task_repo" ]]; then
    mkdir -p "$(dirname -- "$task_repo")"
    git clone https://github.com/microsoft/DCVC.git "$task_repo"
fi
task_rt="$task_repo/DCVC-family/DCVC-RT"
test -f "$task_rt/src/cpp/setup.py"
test -f "$task_rt/src/layers/extensions/inference/setup.py"
mkdir -p "$task_prefix/dcvc-build-records"
git -C "$task_repo" rev-parse HEAD > "$task_prefix/dcvc-build-records/repo-commit.txt"
git -C "$task_repo" status --short > "$task_prefix/dcvc-build-records/repo-status.txt"

cd "$task_rt"
python -m pip install -r requirements.txt
cd "$task_rt/src/cpp"
python -m pip install --no-build-isolation .
cd "$task_rt/src/layers/extensions/inference"
python -m pip install --no-build-isolation .
cd "$task_rt"
python "$task_script_dir/check_environment.py" --strict --extensions \
    > "$task_prefix/dcvc-build-records/environment-with-extensions.json"
python -m pip check
echo "Both DCVC-RT extensions loaded successfully."
echo "Repository: $task_rt"
echo "Report: $task_prefix/dcvc-build-records/environment-with-extensions.json"
echo "Next: obtain the two RT pretrained checkpoints, then run the 24-frame test."
