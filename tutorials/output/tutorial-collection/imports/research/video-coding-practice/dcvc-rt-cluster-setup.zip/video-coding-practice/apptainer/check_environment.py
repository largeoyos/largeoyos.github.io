"""Inspect DCVC-RT dependencies; --strict exits nonzero if checks fail."""
import argparse
import importlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import re


def command(args):
    if not shutil.which(args[0]):
        return {"available": False}
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=20)
        return {"returncode": result.returncode, "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip()[:2000]}
    except Exception as error:
        return {"error": str(error)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", action="store_true", help="Require A100/Python3.12/torch2.6/cu126")
    parser.add_argument("--extensions", action="store_true", help="Also import both compiled DCVC-RT modules")
    args = parser.parse_args()
    result = {
        "python": sys.version, "python_executable": sys.executable,
        "cwd": str(Path.cwd()),
        "environment": {key: os.environ.get(key) for key in
                        ["APPTAINER_CONTAINER", "APPTAINER_NAME", "SINGULARITY_CONTAINER",
                         "CUDA_VISIBLE_DEVICES", "CUDA_HOME", "CONDA_PREFIX",
                         "CC", "CXX", "CUDAHOSTCXX", "TORCH_CUDA_ARCH_LIST", "SLURM_JOB_ID"]},
        "tools": {name: shutil.which(name) for name in
                  ["python", "python3", "conda", "nvcc", "git", "cmake", "g++", "ninja", "ffmpeg"]},
        "nvidia_smi": command(["nvidia-smi"]),
        "cuda_toolkit": command(["nvcc", "--version"]),
    }
    result["compilers"] = {}
    for key in ("CC", "CXX"):
        value = os.environ.get(key) or ("gcc" if key == "CC" else "g++")
        result["compilers"][key] = command([value, "--version"])
    if importlib.util.find_spec("torch") is None:
        result["pytorch"] = {"installed": False}
    else:
        try:
            import torch
            available = torch.cuda.is_available()
            info = {"version": torch.__version__, "cuda_runtime": torch.version.cuda,
                    "cuda_available": available, "gpu_count": torch.cuda.device_count(),
                    "compiled_architectures": torch.cuda.get_arch_list()}
            if available:
                properties = torch.cuda.get_device_properties(0)
                info.update({"gpu": properties.name,
                             "memory_gib": round(properties.total_memory / 1024 ** 3, 2),
                             "capability": list(torch.cuda.get_device_capability(0))})
                with torch.no_grad():
                    tensor = torch.ones((4, 4), device="cuda", dtype=torch.float16)
                    info["fp16_matmul_result"] = (tensor @ tensor)[0, 0].item()
                    torch.cuda.synchronize()
            result["pytorch"] = info
        except Exception as error:
            result["pytorch"] = {"error": str(error)}
    if args.extensions:
        result["extensions"] = {}
        for name in ("MLCodec_extensions_cpp", "inference_extensions_cuda"):
            try:
                module = importlib.import_module(name)
                result["extensions"][name] = {"imported": True, "path": module.__file__}
            except Exception as error:
                result["extensions"][name] = {"imported": False, "error": str(error)}
    if args.strict:
        info = result["pytorch"]
        toolkit = result["cuda_toolkit"]
        checks = {
            "linux_x86_64": sys.platform == "linux" and os.uname().machine == "x86_64",
            "python_312": sys.version_info[:2] == (3, 12),
            "torch_26": re.match(r"^2\.6\.", info.get("version", "")) is not None,
            "torch_cuda_126": info.get("cuda_runtime") == "12.6",
            "allocated_a100": info.get("cuda_available", False) and "A100" in info.get("gpu", ""),
            "fp16_matmul": info.get("fp16_matmul_result") == 4.0,
            "nvcc_126": toolkit.get("returncode") == 0 and "release 12.6" in toolkit.get("stdout", ""),
            "build_tools": all(result["tools"][name] for name in ("git", "cmake", "ninja")),
            "compilers": all(value.get("returncode") == 0 for value in result["compilers"].values()),
            "cuda_home": bool(os.environ.get("CUDA_HOME")) and Path(os.environ["CUDA_HOME"], "bin", "nvcc").is_file(),
        }
        if args.extensions:
            checks["extensions"] = all(item["imported"] for item in result["extensions"].values())
        result["checks"] = checks
        result["passed"] = all(checks.values())
    print(json.dumps(result, indent=2))
    if args.strict and not result["passed"]:
        print("Environment checks failed: " + ", ".join(name for name, passed in checks.items() if not passed), file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
