#!/usr/bin/env bash
# Run inside the user's allocated Apptainer GPU session.
# Clone the public py312 environment, then install dedicated build dependencies.
# Usage: bash apptainer/setup_dcvc_rt.sh [ENV_PREFIX] [PUBLIC_PY312_PREFIX]
set -euo pipefail

if [[ ${1:-} == --help ]]; then
    echo "Usage: bash apptainer/setup_dcvc_rt.sh [ENV_PREFIX] [PUBLIC_PY312_PREFIX]"
    echo "Default target: \$HOME/envs/dcvc-rt; run inside an allocated A100 session."
    exit 0
fi
task_prefix="${1:-$HOME/envs/dcvc-rt}"
task_clone="${2:-/public/app/miniconda3/py312_24.4.0-0/envs/py312}"
task_script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
if [[ "$task_prefix" != /* || "$task_prefix" == "/" || "$task_prefix" == *".."* ]]; then
    echo "Supply an absolute path for a new dedicated environment." >&2
    exit 2
fi
if [[ "$task_prefix" != "$HOME"/envs/dcvc-rt* ]]; then
    echo "Choose a dedicated destination under \$HOME/envs/dcvc-rt*." >&2
    exit 2
fi
if [[ $(uname -s) != Linux || $(uname -m) != x86_64 ]]; then
    echo "This script targets the supplied Linux x86_64 A100 session." >&2
    exit 2
fi
task_conda="${CONDA_EXE:-}"
if [[ -z "$task_conda" ]]; then
    task_conda=$(type -P conda || true)
fi
if [[ ! -x "$task_conda" ]]; then
    echo "Conda executable not found. Run from a shell with Conda initialized." >&2
    exit 2
fi

if [[ -e "$task_prefix" && ! -f "$task_prefix/conda-meta/history" ]]; then
    echo "The destination already exists and is not a Conda environment: $task_prefix" >&2
    exit 2
fi
if [[ ! -f "$task_prefix/conda-meta/history" && ! -f "$task_clone/conda-meta/history" ]]; then
    echo "Public Python 3.12 environment is not visible: $task_clone" >&2
    echo "Pass its actual path as the second argument." >&2
    exit 2
fi
nvidia-smi --query-gpu=name --format=csv,noheader | grep -q A100 || {
    echo "No A100 visible. Open an allocated A100 Apptainer session first." >&2
    exit 2
}
export CONDA_PKGS_DIRS="${DCVC_CONDA_PKGS_DIRS:-$HOME/.cache/dcvc-rt/conda-pkgs}"
mkdir -p "$CONDA_PKGS_DIRS" "$(dirname -- "$task_prefix")"
if [[ ! -f "$task_prefix/conda-meta/history" ]]; then
    "$task_conda" create -y -p "$task_prefix" --clone "$task_clone"
fi

# Activation scripts select Conda's compatible C/C++ compilers.
set +u
eval "$("$task_conda" shell.bash hook)"
conda activate "$task_prefix"
set -u
python -c 'import sys; assert sys.version_info[:2] == (3,12), sys.version'
"$task_conda" install -y -p "$task_prefix" --override-channels \
    -c nvidia/label/cuda-12.6.3 -c conda-forge \
    python=3.12 pip cuda-toolkit=12.6.3 \
    gcc_linux-64=12 gxx_linux-64=12 git cmake ninja
# Reapply activation hooks from the newly installed compiler packages.
set +u
conda deactivate
conda activate "$task_prefix"
set -u
export CUDA_HOME="$task_prefix"
export MAX_JOBS=4
export TORCH_CUDA_ARCH_LIST="8.0"

python -m pip install torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0 \
    --index-url https://download.pytorch.org/whl/cu126
python -m pip install setuptools wheel pybind11 numpy scipy matplotlib tqdm pillow bd-metric

# Persist only these build settings in the dedicated environment.
conda env config vars set -p "$task_prefix" CUDA_HOME="$task_prefix" MAX_JOBS=4 TORCH_CUDA_ARCH_LIST="8.0"
nvcc --version
python -c 'import torch; assert torch.cuda.is_available(), "CUDA unavailable"; x=torch.ones((4,4),device="cuda",dtype=torch.float16); print("PyTorch:",torch.__version__,"CUDA:",torch.version.cuda,"GPU:",torch.cuda.get_device_name(0),"matmul:",(x@x)[0,0].item())'
python -m pip check
python "$task_script_dir/check_environment.py" --strict > "$task_prefix/dcvc-environment.json"
python -m pip freeze > "$task_prefix/dcvc-pip-freeze.txt"
"$task_conda" list -p "$task_prefix" --explicit > "$task_prefix/dcvc-conda-explicit.txt"
echo "Environment ready: $task_prefix"
echo "Report: $task_prefix/dcvc-environment.json"
echo "Activate in your current terminal: conda activate $task_prefix"
echo "Next: bash apptainer/build_dcvc_rt.sh"
