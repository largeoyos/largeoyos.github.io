param(
    [Parameter(Mandatory = $true)]
    [string]$Url,

    [Parameter(Mandatory = $true)]
    [string]$Output,

    [Parameter(Mandatory = $true)]
    [long]$TotalBytes,

    [Parameter(Mandatory = $true)]
    [string]$ExpectedSha256,

    [int]$Segments = 8
)

$ErrorActionPreference = "Stop"
if ($Segments -lt 1 -or $Segments -gt 16) {
    throw "Segments must be between 1 and 16"
}

$Output = [System.IO.Path]::GetFullPath($Output)
$PartsDir = "$Output.parts"
New-Item -ItemType Directory -Force -Path $PartsDir | Out-Null
$SegmentSize = [long][Math]::Ceiling($TotalBytes / [double]$Segments)
$PartSpecs = @()

for ($Index = 0; $Index -lt $Segments; $Index++) {
    $Start = [long]$Index * $SegmentSize
    $End = [Math]::Min($TotalBytes - 1, $Start + $SegmentSize - 1)
    if ($Start -gt $End) { break }
    $PartPath = Join-Path $PartsDir ("part-{0:D2}.bin" -f $Index)
    $ExpectedLength = $End - $Start + 1

    if (Test-Path -LiteralPath $PartPath) {
        $ExistingLength = (Get-Item -LiteralPath $PartPath).Length
        if ($ExistingLength -ne $ExpectedLength) {
            Remove-Item -LiteralPath $PartPath -Force
        }
    }

    $PartSpecs += [PSCustomObject]@{
        Index = $Index
        Start = $Start
        End = $End
        Path = $PartPath
        Length = $ExpectedLength
    }
}

$Jobs = @()
foreach ($Part in $PartSpecs) {
    if (Test-Path -LiteralPath $Part.Path) { continue }
    $Jobs += Start-Job -ScriptBlock {
        param($DownloadUrl, $RangeStart, $RangeEnd, $PartPath)
        curl.exe --silent --show-error --location --fail `
            --retry 20 --retry-all-errors --retry-delay 3 `
            --range "$RangeStart-$RangeEnd" --output $PartPath $DownloadUrl
        if ($LASTEXITCODE -ne 0) {
            throw "curl failed for range $RangeStart-$RangeEnd"
        }
    } -ArgumentList $Url, $Part.Start, $Part.End, $Part.Path
}

while (($Jobs | Where-Object State -eq "Running").Count -gt 0) {
    Start-Sleep -Seconds 10
    $Downloaded = 0L
    foreach ($Part in $PartSpecs) {
        if (Test-Path -LiteralPath $Part.Path) {
            $Downloaded += (Get-Item -LiteralPath $Part.Path).Length
        }
    }
    $Percent = 100.0 * $Downloaded / $TotalBytes
    Write-Host ("parallel download: {0:N1}% ({1:N0}/{2:N0} bytes)" -f $Percent, $Downloaded, $TotalBytes)
}

foreach ($Job in $Jobs) {
    Receive-Job -Job $Job
    if ($Job.State -ne "Completed") {
        throw "A parallel download segment failed"
    }
    Remove-Job -Job $Job
}

foreach ($Part in $PartSpecs) {
    if (-not (Test-Path -LiteralPath $Part.Path)) {
        throw "Missing segment: $($Part.Path)"
    }
    $ActualLength = (Get-Item -LiteralPath $Part.Path).Length
    if ($ActualLength -ne $Part.Length) {
        throw "Segment length mismatch for $($Part.Path): $ActualLength"
    }
}

$Assembled = "$Output.assembled"
$OutputStream = [System.IO.File]::Open(
    $Assembled,
    [System.IO.FileMode]::Create,
    [System.IO.FileAccess]::Write,
    [System.IO.FileShare]::None
)
try {
    foreach ($Part in ($PartSpecs | Sort-Object Index)) {
        $InputStream = [System.IO.File]::OpenRead($Part.Path)
        try {
            $InputStream.CopyTo($OutputStream, 4MB)
        }
        finally {
            $InputStream.Dispose()
        }
    }
}
finally {
    $OutputStream.Dispose()
}

$ActualSha256 = (Get-FileHash -LiteralPath $Assembled -Algorithm SHA256).Hash.ToLowerInvariant()
if ($ActualSha256 -ne $ExpectedSha256.ToLowerInvariant()) {
    throw "Assembled wheel hash mismatch: $ActualSha256"
}

Move-Item -LiteralPath $Assembled -Destination $Output -Force
foreach ($Part in $PartSpecs) {
    Remove-Item -LiteralPath $Part.Path -Force
}
Remove-Item -LiteralPath $PartsDir -Force
Write-Host "verified download: $Output"
