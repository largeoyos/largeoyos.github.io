$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $ProjectRoot
$InstallTemp = Join-Path $ProjectRoot ".tmp\pip"
New-Item -ItemType Directory -Force -Path $InstallTemp | Out-Null
$env:TEMP = $InstallTemp
$env:TMP = $InstallTemp

if (-not (Test-Path -LiteralPath ".venv\Scripts\python.exe")) {
    python -m venv --without-pip .venv
}

# This Python distribution cannot run ensurepip. Extract its bundled pip wheel
# into the project venv, then use the venv interpreter for every install.
if (-not (Test-Path -LiteralPath ".venv\Lib\site-packages\pip")) {
    $BundledPip = python -c "import ensurepip, pathlib; print(next((pathlib.Path(ensurepip.__file__).parent / '_bundled').glob('pip-*.whl')))"
    tar -xf $BundledPip -C .venv\Lib\site-packages
}

$DownloadDir = Join-Path $ProjectRoot ".downloads"
$TorchWheel = Join-Path $DownloadDir "torch-2.11.0+cu128-cp312-cp312-win_amd64.whl"
$TorchUrl = "https://mirrors.aliyun.com/pytorch-wheels/cu128/torch-2.11.0%2Bcu128-cp312-cp312-win_amd64.whl"
$TorchSha256 = "7c78215c3af4f62e63f2b2e360f1722fc719b0853c7ac22666483d9810613a4c"
$TorchBytes = 2753189216
New-Item -ItemType Directory -Force -Path $DownloadDir | Out-Null

if (-not (Test-Path -LiteralPath $TorchWheel) -or
    (Get-FileHash -LiteralPath $TorchWheel -Algorithm SHA256).Hash.ToLowerInvariant() -ne $TorchSha256) {
    & "$ProjectRoot\download_torch_parallel.ps1" `
        -Url $TorchUrl `
        -Output $TorchWheel `
        -TotalBytes $TorchBytes `
        -ExpectedSha256 $TorchSha256 `
        -Segments 8
}

$ActualTorchHash = (Get-FileHash -LiteralPath $TorchWheel -Algorithm SHA256).Hash.ToLowerInvariant()
if ($ActualTorchHash -ne $TorchSha256) {
    throw "PyTorch wheel hash mismatch: $ActualTorchHash"
}

.\.venv\Scripts\python.exe -m pip install --no-cache-dir --no-deps $TorchWheel
if ($LASTEXITCODE -ne 0) { throw "PyTorch wheel installation failed" }
.\.venv\Scripts\python.exe -m pip install --no-cache-dir -e ".[dev]"
if ($LASTEXITCODE -ne 0) { throw "Project dependency installation failed" }

.\.venv\Scripts\lic-check.exe
