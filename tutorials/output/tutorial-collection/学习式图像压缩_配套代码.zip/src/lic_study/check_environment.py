"""Print the runtime facts needed to reproduce experiments."""

from __future__ import annotations

import platform
import sys


def main() -> None:
    import torch

    print(f"Python: {sys.version.split()[0]}")
    print(f"Platform: {platform.platform()}")
    print(f"PyTorch: {torch.__version__}")
    print(f"CUDA build: {torch.version.cuda}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        props = torch.cuda.get_device_properties(0)
        print(f"GPU: {props.name}")
        print(f"GPU memory: {props.total_memory / 1024**3:.2f} GiB")


if __name__ == "__main__":
    main()
