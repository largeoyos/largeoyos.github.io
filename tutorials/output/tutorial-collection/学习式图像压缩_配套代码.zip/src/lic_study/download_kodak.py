"""Download a fixed subset of the public Kodak lossless image suite."""

from __future__ import annotations

import argparse
import urllib.request
from pathlib import Path


KODAK_URL = "https://r0k.us/graphics/kodak/kodak/kodim{index:02d}.png"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--count",
        type=int,
        default=1,
        choices=range(1, 25),
        metavar="1..24",
        help="number of Kodak images to download (default: 1)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data/kodak"),
        help="destination directory (default: data/kodak)",
    )
    return parser.parse_args()


def download_image(index: int, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / f"kodim{index:02d}.png"
    if target.exists() and target.stat().st_size > 0:
        print(f"exists: {target}")
        return target

    request = urllib.request.Request(
        KODAK_URL.format(index=index),
        headers={"User-Agent": "learned-image-compression-study/0.1"},
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        payload = response.read()
    target.write_bytes(payload)
    print(f"downloaded: {target} ({len(payload)} bytes)")
    return target


def main() -> None:
    args = parse_args()
    for index in range(1, args.count + 1):
        download_image(index, args.output_dir)


if __name__ == "__main__":
    main()
