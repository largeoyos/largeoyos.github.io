"""Evaluate a trained toy codec and save its reconstruction and metrics."""

from __future__ import annotations

import argparse
import json
import time
from datetime import UTC, datetime
from pathlib import Path

import torch
from pytorch_msssim import ms_ssim

from .image_io import load_rgb_tensor, pad_to_factor, save_rgb_tensor
from .metrics import psnr_rgb
from .model import FactorizedPriorCodec, rate_distortion_loss
from .train_toy import resolve_device


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("checkpoints/toy_factorized_smoke.pt"),
    )
    parser.add_argument("--rd-lambda", type=float, default=0.01)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    device = resolve_device(args.device)
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    model = FactorizedPriorCodec(**checkpoint["model_config"]).to(device)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()

    original = load_rgb_tensor(args.image).unsqueeze(0)
    height, width = original.shape[-2:]
    padded, padded_shape = pad_to_factor(
        original, FactorizedPriorCodec.downsampling_factor
    )
    padded = padded.to(device)
    with torch.inference_mode():
        if device.type == "cuda":
            torch.cuda.synchronize()
        started = time.perf_counter()
        output = model(padded)
        if device.type == "cuda":
            torch.cuda.synchronize()
        elapsed = time.perf_counter() - started

    reconstruction = output.reconstruction[..., :height, :width]
    likelihoods = output.likelihoods
    # Padding is represented in the latent, but rate is normalized by original pixels.
    estimated_bpp = float(-torch.log2(likelihoods).sum() / (height * width))
    reference = original.to(device)
    psnr = psnr_rgb(reference, reconstruction)
    ms_ssim_value = float(
        ms_ssim(reference, reconstruction, data_range=1.0, size_average=True)
    )
    rd = rate_distortion_loss(padded, output, args.rd_lambda)

    stem = f"{args.image.stem}_toy_factorized"
    reconstruction_path = args.output_dir / f"{stem}_reconstruction.png"
    metrics_path = args.output_dir / f"{stem}_metrics.json"
    save_rgb_tensor(reconstruction, reconstruction_path)
    metrics = {
        "timestamp_utc": datetime.now(UTC).isoformat(),
        "scope": "smoke_test_not_a_scientific_benchmark",
        "rate_kind": "estimated_from_factorized_gaussian_likelihood_not_actual_bitstream",
        "image": str(args.image.resolve()),
        "checkpoint": str(args.checkpoint.resolve()),
        "device": str(device),
        "original_shape_hw": [height, width],
        "padded_shape_hw": list(padded_shape),
        "estimated_bpp": estimated_bpp,
        "psnr_rgb_db": psnr,
        "ms_ssim_rgb": ms_ssim_value,
        "padded_rd_loss": float(rd.total),
        "inference_seconds": elapsed,
        "model_parameters": sum(p.numel() for p in model.parameters()),
        "torch_version": torch.__version__,
        "cuda_build": torch.version.cuda,
    }
    metrics_path.parent.mkdir(parents=True, exist_ok=True)
    metrics_path.write_text(
        json.dumps(metrics, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(metrics, indent=2, ensure_ascii=False))
    print(f"reconstruction: {reconstruction_path}")
    print(f"metrics: {metrics_path}")
