"""Image loading, patch sampling and tensor serialization helpers."""

from __future__ import annotations

import random
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch import Tensor
from torch.nn import functional as F
from torch.utils.data import Dataset


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}


def discover_images(root: Path) -> list[Path]:
    paths = sorted(
        path for path in root.rglob("*") if path.suffix.lower() in IMAGE_SUFFIXES
    )
    if not paths:
        raise FileNotFoundError(f"no images found under: {root}")
    return paths


def load_rgb_tensor(path: Path) -> Tensor:
    if not path.is_file():
        raise FileNotFoundError(f"image not found: {path}")
    with Image.open(path) as image:
        array = np.array(image.convert("RGB"), dtype=np.float32, copy=True) / 255.0
    return torch.from_numpy(array).permute(2, 0, 1)


def save_rgb_tensor(tensor: Tensor, path: Path) -> None:
    array = (
        tensor.detach()
        .squeeze(0)
        .clamp(0, 1)
        .permute(1, 2, 0)
        .mul(255)
        .round()
        .byte()
        .cpu()
        .numpy()
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(array).save(path)


def pad_to_factor(image: Tensor, factor: int) -> tuple[Tensor, tuple[int, int]]:
    height, width = image.shape[-2:]
    padded_height = ((height + factor - 1) // factor) * factor
    padded_width = ((width + factor - 1) // factor) * factor
    padded = F.pad(image, (0, padded_width - width, 0, padded_height - height))
    return padded, (padded_height, padded_width)


class RandomImagePatchDataset(Dataset[Tensor]):
    """Sample random fixed-size patches from a directory of RGB images."""

    def __init__(
        self,
        root: Path,
        patch_size: int,
        samples_per_epoch: int,
    ) -> None:
        if patch_size <= 0 or samples_per_epoch <= 0:
            raise ValueError("patch_size and samples_per_epoch must be positive")
        self.paths = discover_images(root)
        self.patch_size = patch_size
        self.samples_per_epoch = samples_per_epoch

    def __len__(self) -> int:
        return self.samples_per_epoch

    def __getitem__(self, _: int) -> Tensor:
        image = load_rgb_tensor(random.choice(self.paths))
        _, height, width = image.shape
        if min(height, width) < self.patch_size:
            scale = self.patch_size / min(height, width)
            resized_height = max(self.patch_size, round(height * scale))
            resized_width = max(self.patch_size, round(width * scale))
            image = F.interpolate(
                image.unsqueeze(0),
                size=(resized_height, resized_width),
                mode="bilinear",
                align_corners=False,
            ).squeeze(0)
            _, height, width = image.shape

        top = random.randint(0, height - self.patch_size)
        left = random.randint(0, width - self.patch_size)
        patch = image[
            :,
            top : top + self.patch_size,
            left : left + self.patch_size,
        ]
        if random.random() < 0.5:
            patch = torch.flip(patch, dims=(2,))
        return patch.contiguous()
