"""Metric helpers kept independent from CompressAI for fast unit tests."""

from __future__ import annotations

import math
import torch
from torch import Tensor
from torch.nn import functional as F


def psnr_rgb(reference: Tensor, reconstruction: Tensor) -> float:
    """Return RGB PSNR for tensors whose valid value range is [0, 1]."""
    if reference.shape != reconstruction.shape:
        raise ValueError(
            "reference and reconstruction must have the same shape, "
            f"got {tuple(reference.shape)} and {tuple(reconstruction.shape)}"
        )

    mse = F.mse_loss(reconstruction, reference).item()
    if mse == 0:
        return math.inf
    return -10.0 * math.log10(mse)


def estimated_bpp(likelihoods: Tensor, pixel_count: int) -> Tensor:
    """Estimate bits per pixel from a differentiable latent likelihood."""
    if pixel_count <= 0:
        raise ValueError("pixel_count must be positive")
    if torch.any(likelihoods <= 0):
        raise ValueError("likelihoods must be positive")
    return -torch.log2(likelihoods).sum() / pixel_count
