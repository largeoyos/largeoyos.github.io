"""A small educational learned image codec with a factorized Gaussian prior."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .metrics import estimated_bpp


@dataclass
class CodecOutput:
    reconstruction: Tensor
    latent: Tensor
    likelihoods: Tensor


@dataclass
class RateDistortionLoss:
    total: Tensor
    bpp: Tensor
    mse: Tensor


class FactorizedPriorCodec(nn.Module):
    """A lightweight analysis/quantization/synthesis model for local study.

    The entropy model is a zero-dependency, per-channel Gaussian prior. It is
    intentionally smaller than research baselines such as CompressAI and does
    not implement arithmetic coding; reported rate is therefore estimated bpp.
    """

    downsampling_factor = 16

    def __init__(self, hidden_channels: int = 64, latent_channels: int = 96) -> None:
        super().__init__()
        h = hidden_channels
        m = latent_channels
        self.hidden_channels = h
        self.latent_channels = m

        self.encoder = nn.Sequential(
            nn.Conv2d(3, h, kernel_size=5, stride=2, padding=2),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(h, h, kernel_size=5, stride=2, padding=2),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(h, h, kernel_size=5, stride=2, padding=2),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(h, m, kernel_size=5, stride=2, padding=2),
        )
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(m, h, 5, stride=2, padding=2, output_padding=1),
            nn.LeakyReLU(0.1, inplace=True),
            nn.ConvTranspose2d(h, h, 5, stride=2, padding=2, output_padding=1),
            nn.LeakyReLU(0.1, inplace=True),
            nn.ConvTranspose2d(h, h, 5, stride=2, padding=2, output_padding=1),
            nn.LeakyReLU(0.1, inplace=True),
            nn.ConvTranspose2d(h, 3, 5, stride=2, padding=2, output_padding=1),
        )
        self.prior_mean = nn.Parameter(torch.zeros(m))
        self.prior_log_scale = nn.Parameter(torch.zeros(m))

    def quantize(self, latent: Tensor) -> Tensor:
        if self.training:
            noise = torch.empty_like(latent).uniform_(-0.5, 0.5)
            return latent + noise
        return torch.round(latent)

    def likelihood(self, quantized_latent: Tensor) -> Tensor:
        mean = self.prior_mean.view(1, -1, 1, 1)
        scale = F.softplus(self.prior_log_scale).view(1, -1, 1, 1) + 1e-4
        centered = quantized_latent - mean
        upper = (centered + 0.5) / scale
        lower = (centered - 0.5) / scale
        likelihood = torch.special.ndtr(upper) - torch.special.ndtr(lower)
        return likelihood.clamp_min(1e-9)

    def forward(self, image: Tensor) -> CodecOutput:
        latent = self.encoder(image)
        quantized = self.quantize(latent)
        likelihoods = self.likelihood(quantized)
        reconstruction = torch.sigmoid(self.decoder(quantized))
        return CodecOutput(reconstruction, quantized, likelihoods)


def rate_distortion_loss(
    image: Tensor,
    output: CodecOutput,
    rd_lambda: float,
) -> RateDistortionLoss:
    pixel_count = image.shape[0] * image.shape[2] * image.shape[3]
    bpp = estimated_bpp(output.likelihoods, pixel_count)
    mse = F.mse_loss(output.reconstruction, image)
    total = bpp + rd_lambda * (255.0**2) * mse
    return RateDistortionLoss(total=total, bpp=bpp, mse=mse)
