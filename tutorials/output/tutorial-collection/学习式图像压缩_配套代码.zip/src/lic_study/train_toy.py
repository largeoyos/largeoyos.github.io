"""Train the lightweight factorized-prior codec on image patches."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from .image_io import RandomImagePatchDataset
from .model import FactorizedPriorCodec, rate_distortion_loss


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("data/kodak"))
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--steps-per-epoch", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--patch-size", type=int, default=128)
    parser.add_argument("--hidden-channels", type=int, default=64)
    parser.add_argument("--latent-channels", type=int, default=96)
    parser.add_argument("--rd-lambda", type=float, default=0.01)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=20260828)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("checkpoints/toy_factorized_smoke.pt"),
    )
    parser.add_argument(
        "--history",
        type=Path,
        default=Path("outputs/toy_factorized_smoke_history.json"),
    )
    return parser.parse_args()


def resolve_device(name: str) -> torch.device:
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    if name == "cuda" or (name == "auto" and torch.cuda.is_available()):
        return torch.device("cuda")
    return torch.device("cpu")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def main() -> None:
    args = parse_args()
    if args.epochs <= 0 or args.steps_per_epoch <= 0 or args.batch_size <= 0:
        raise ValueError("epochs, steps-per-epoch and batch-size must be positive")
    if args.patch_size % FactorizedPriorCodec.downsampling_factor != 0:
        raise ValueError("patch-size must be divisible by 16")

    set_seed(args.seed)
    device = resolve_device(args.device)
    dataset = RandomImagePatchDataset(
        args.data_dir,
        patch_size=args.patch_size,
        samples_per_epoch=args.steps_per_epoch * args.batch_size,
    )
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    model = FactorizedPriorCodec(
        hidden_channels=args.hidden_channels,
        latent_channels=args.latent_channels,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    use_amp = device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    history: list[dict[str, float | int]] = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        totals = {"loss": 0.0, "bpp": 0.0, "mse": 0.0}
        for image in loader:
            image = image.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast(device_type=device.type, enabled=use_amp):
                output = model(image)
                loss = rate_distortion_loss(image, output, args.rd_lambda)
            scaler.scale(loss.total).backward()
            scaler.step(optimizer)
            scaler.update()
            totals["loss"] += float(loss.total.detach())
            totals["bpp"] += float(loss.bpp.detach())
            totals["mse"] += float(loss.mse.detach())

        steps = len(loader)
        record: dict[str, float | int] = {
            "epoch": epoch,
            "loss": totals["loss"] / steps,
            "estimated_bpp": totals["bpp"] / steps,
            "mse": totals["mse"] / steps,
        }
        history.append(record)
        print(json.dumps(record, ensure_ascii=False))

    args.checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_state": model.state_dict(),
            "model_config": {
                "hidden_channels": args.hidden_channels,
                "latent_channels": args.latent_channels,
            },
            "training_config": {
                **vars(args),
                "data_dir": str(args.data_dir),
                "checkpoint": str(args.checkpoint),
                "history": str(args.history),
            },
            "history": history,
            "torch_version": torch.__version__,
        },
        args.checkpoint,
    )
    args.history.parent.mkdir(parents=True, exist_ok=True)
    args.history.write_text(
        json.dumps(history, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"checkpoint: {args.checkpoint}")
    print(f"history: {args.history}")
