#!/usr/bin/env bash
# Run from an allocated GPU host session, not from an existing container shell.
# Usage: bash apptainer/exec.sh /absolute/path/image.sif python3 apptainer/check_environment.py
set -euo pipefail

if (( $# < 2 )); then
    echo "Usage: bash apptainer/exec.sh IMAGE.sif COMMAND [ARGUMENTS...]" >&2
    exit 2
fi
task_image=$(realpath -- "$1")
shift
task_workspace=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
test -f "$task_image"
command -v apptainer >/dev/null

# Preserve the scheduler's GPU allocation while clearing unrelated host Python settings.
if [[ ${CUDA_VISIBLE_DEVICES+x} ]]; then
    export APPTAINERENV_CUDA_VISIBLE_DEVICES="$CUDA_VISIBLE_DEVICES"
fi

# Same absolute path inside/outside keeps dataset and virtual-environment paths stable.
exec apptainer exec --nv --cleanenv \
    --bind "$task_workspace:$task_workspace" --pwd "$task_workspace" \
    "$task_image" "$@"
