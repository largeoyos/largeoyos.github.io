"""Read-only inventory of the user's allocated BitaHub container."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def command(args, timeout=20):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return {"returncode": result.returncode, "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip()[:2000]}
    except Exception as error:
        return {"error": str(error)}


result = {"hostname": os.uname().nodename, "cwd": os.getcwd(), "python": sys.version,
          "environment": {key: os.environ.get(key) for key in
                          ["CUDA_VISIBLE_DEVICES", "NVIDIA_VISIBLE_DEVICES", "CUDA_HOME",
                           "CONDA_PREFIX", "CONDA_DEFAULT_ENV"]},
          "tools": {name: shutil.which(name) for name in
                    ["python", "python3", "conda", "pip", "nvcc", "git", "cmake", "g++",
                     "ninja", "ffmpeg", "curl", "wget"]}, "directories": {}}
for directory in ["/code", "/data", "/model", "/output", "/opt", "/usr/local/cuda"]:
    path = Path(directory)
    if path.exists():
        usage = shutil.disk_usage(path)
        result["directories"][directory] = {
            "entries": sorted(item.name for item in path.iterdir())[:40],
            "free_gib": round(usage.free / 1024 ** 3, 2),
            "real_path": str(path.resolve()),
        }
result["os_release"] = Path("/etc/os-release").read_text()
result["gpu"] = command(["nvidia-smi"])
result["nvcc"] = command(["nvcc", "--version"])
result["mounts"] = command(["findmnt", "-T", "/code"])
result["torch"] = command([sys.executable, "-c",
    "import json,torch; ok=torch.cuda.is_available(); "
    "print(json.dumps({'version':torch.__version__,'cuda':torch.version.cuda,"
    "'available':ok,'gpu':torch.cuda.get_device_name(0) if ok else None,"
    "'capability':torch.cuda.get_device_capability(0) if ok else None,"
    "'arch_list':torch.cuda.get_arch_list()})); "
    "print((torch.ones((2,2),device='cuda') @ torch.ones((2,2),device='cuda')).cpu() if ok else 'no cuda')"
], timeout=40)
print(json.dumps(result, indent=2))
