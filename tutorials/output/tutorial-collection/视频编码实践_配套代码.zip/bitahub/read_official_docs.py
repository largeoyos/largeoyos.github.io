"""Cache public BitaHub help pages and extract their article text."""
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import sys
from urllib.parse import quote, urljoin
from urllib.request import urlopen

sys.stdout.reconfigure(encoding="utf-8")
root = Path(__file__).parent
base = "https://bitahub.ustc.edu.cn/help/"
index = (root / "help-index.html").read_text(encoding="utf-8")


class Parser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.article = False
        self.parts = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and "href" in attrs:
            self.links.append(attrs["href"])
        if tag == "section" and "markdown-section" in attrs.get("class", ""):
            self.article = True
        if self.article and tag in ["p", "h1", "h2", "h3", "h4", "li", "br", "pre"]:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag == "section":
            self.article = False

    def handle_data(self, data):
        if self.article:
            self.parts.append(data)


parser = Parser()
parser.feed(index)
keywords = ["文件结构", "调试", "自定义镜像", "镜像列表", "常见问题", "运行任务", "文件管理"]
selected = [link for link in dict.fromkeys(parser.links)
            if link.startswith("md/") and any(key in link for key in keywords)]
results = []
for link in selected:
    url = urljoin(base, quote(html.unescape(link), safe="/"))
    data = urlopen(url, timeout=25).read()
    article = Parser()
    article.feed(data.decode("utf-8"))
    text = "".join(article.parts).strip()
    name = Path(link).stem
    (root / (name + ".md")).write_text("Source: " + url + "\n\n" + text, encoding="utf-8")
    results.append({"page": name, "url": url, "text": text})
print(json.dumps(results, ensure_ascii=False, indent=2))
