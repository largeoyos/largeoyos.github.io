        PRESERVE8
        THUMB
        AREA    AppCode,CODE,READONLY,ALIGN=2
        EXPORT  exercise_main
exercise_main PROC
        MOVS    R2,#5          ; test input
        MOVS    R3,#8          ; original R3
        CMP     R3,R2          ; signed comparison of original values
        BGT     Greater
        ADD     R3,R2,#100
        B       StoreResult
Greater
        ADD     R3,R2,#10
StoreResult
        LDR     R1,=Result
        STR     R3,[R1]
        BX      LR
        ENDP
        AREA    Results,DATA,READWRITE,NOINIT,ALIGN=2
        EXPORT  Result
Result  SPACE   4
        END
