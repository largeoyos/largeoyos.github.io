        PRESERVE8
        THUMB
        AREA    AppCode,CODE,READONLY,ALIGN=2
        EXPORT  exercise_main
exercise_main PROC
        MOVS    R0,#0
        LDR     R1,=Values
        MOVS    R2,#10
CountLoop
        LDR     R3,[R1],#4
        TST     R3,#1
        BNE     NotEven
        ADDS    R0,R0,#1
NotEven
        SUBS    R2,R2,#1
        BNE     CountLoop
        LDR     R1,=Result
        STR     R0,[R1]
        BX      LR
        ENDP
        AREA    Inputs,DATA,READONLY,ALIGN=2
Values  DCD     -4,-3,0,1,2,3,4,5,6,7
        AREA    Results,DATA,READWRITE,NOINIT,ALIGN=2
        EXPORT  Result
Result  SPACE   4
        END
