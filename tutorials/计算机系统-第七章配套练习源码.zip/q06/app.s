        PRESERVE8
        THUMB
        AREA    AppCode,CODE,READONLY,ALIGN=2
        EXPORT  exercise_main
exercise_main PROC
        MOVS    R0,#0          ; sum
        MOVS    R1,#100        ; next addend
SumLoop
        ADDS    R0,R0,R1
        SUBS    R1,R1,#1
        BNE     SumLoop
        LDR     R2,=Result
        STR     R0,[R2]
        BX      LR
        ENDP
        AREA    Results,DATA,READWRITE,NOINIT,ALIGN=2
        EXPORT  Result
Result  SPACE   4
        END
