        PRESERVE8
        THUMB
        AREA    AppCode,CODE,READONLY,ALIGN=2
        EXPORT  exercise_main
exercise_main PROC
        PUSH    {R4,LR}
        MOVS    R0,#5
        BL      Fact10
        LDR     R1,=Result
        STR     R0,[R1]
        POP     {R4,PC}
        ENDP
Fact10  PROC
        CMP     R0,#10
        BHI     FactBad
        MOV     R1,R0
        MOVS    R0,#1
FactTest
        CMP     R1,#1
        BLS     FactDone
        MUL     R0,R0,R1
        SUBS    R1,R1,#1
        B       FactTest
FactDone
        BX      LR
FactBad
        MOVS    R0,#0
        BX      LR
        ENDP
        AREA    Results,DATA,READWRITE,NOINIT,ALIGN=2
        EXPORT  Result
Result  SPACE   4
        END
