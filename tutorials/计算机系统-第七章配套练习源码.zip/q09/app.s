        PRESERVE8
        THUMB
        AREA    AppCode,CODE,READONLY,ALIGN=2
        EXPORT  exercise_main
        IMPORT  factorial_c
exercise_main PROC
        PUSH    {R4,LR}
        MOVS    R0,#5
        BL      factorial_c
        LDR     R1,=Result
        STR     R0,[R1]
        POP     {R4,PC}
        ENDP
        AREA    Results,DATA,READWRITE,NOINIT,ALIGN=2
        EXPORT  Result
Result  SPACE   4
        END
