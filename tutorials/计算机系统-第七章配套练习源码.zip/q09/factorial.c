unsigned factorial_c(unsigned n)
{
    unsigned acc = 1;
    if (n > 10u) return 0u;
    while (n > 1u) {
        acc *= n;
        --n;
    }
    return acc;
}
