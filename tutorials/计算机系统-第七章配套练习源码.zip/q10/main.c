extern unsigned asm_strlen(const char *s);
volatile unsigned Result;

void exercise_main(void)
{
    Result = asm_strlen("Hello ARM!");
    /* Result = 10; initialization is not assumed before this write. */
    for (;;) { }
}
