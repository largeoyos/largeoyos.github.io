        PRESERVE8
        THUMB
        AREA    StringCode,CODE,READONLY,ALIGN=2
        EXPORT  asm_strlen
asm_strlen PROC
        MOV     R1,R0
        MOVS    R0,#0
LenLoop
        LDRB    R2,[R1],#1
        CMP     R2,#0
        BEQ     LenDone
        ADDS    R0,R0,#1
        B       LenLoop
LenDone
        BX      LR
        ENDP
        END
