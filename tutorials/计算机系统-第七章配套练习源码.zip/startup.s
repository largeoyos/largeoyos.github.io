        PRESERVE8
        THUMB
Stack_Size EQU  0x400
        AREA    STACK,NOINIT,READWRITE,ALIGN=3
Stack_Mem SPACE Stack_Size
__initial_sp
        AREA    RESET,DATA,READONLY,ALIGN=7
        EXPORT  __Vectors
__Vectors
        DCD     __initial_sp
        DCD     Reset_Handler
        DCD     Default_Handler     ; NMI
        DCD     Default_Handler     ; HardFault
        DCD     Default_Handler     ; MemManage
        DCD     Default_Handler     ; BusFault
        DCD     Default_Handler     ; UsageFault
        DCD     0,0,0,0
        DCD     Default_Handler     ; SVC
        DCD     Default_Handler     ; DebugMon
        DCD     0
        DCD     Default_Handler     ; PendSV
        DCD     Default_Handler     ; SysTick
        AREA    StartupCode,CODE,READONLY
        IMPORT  exercise_main
        EXPORT  Reset_Handler
Reset_Handler PROC
        CPSID   I
        BL      exercise_main
Halt
        B       Halt
        ENDP
Default_Handler PROC
        B       Default_Handler
        ENDP
        END
