#ifndef CH8_PAGE_CHUNKS_H
#define CH8_PAGE_CHUNKS_H
#include <stdint.h>
#include <stddef.h>
/* Caller supplies a page transaction; it must wait with a timeout for write completion. */
typedef int (*page_writer)(uint32_t address,const uint8_t *data,size_t length);
static inline int write_pages(uint32_t address,const uint8_t *data,size_t length,
                              uint32_t capacity,uint32_t page,page_writer put)
{
    size_t count;
    if(!page || address>capacity || length>capacity-address || !put) return 0;
    if(length && !data) return 0;
    while(length) {
        count=page-(address%page); if(count>length) count=length;
        if(!put(address,data,count)) return 0;
        address+=(uint32_t)count; data+=count; length-=count;
    }
    return 1;
}
#endif
