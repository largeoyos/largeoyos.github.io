#include "board.h"
volatile uint32_t ms;
int board_clock_8mhz(void)
{
    uint32_t n=1000000u;
    RCC->CR |= 1u;
    while (!(RCC->CR & 2u) && --n) { }
    if (!n) return 0;
    RCC->CFGR &= ~3u;              /* select HSI */
    n=1000000u;
    while ((RCC->CFGR & 12u) && --n) { }
    if (!n) return 0;
    RCC->CFGR &= ~((15u<<4)|(7u<<8)|(7u<<11));
    RCC->CR &= ~(1u<<24);          /* PLL no longer the system source */
    SystemCoreClock=8000000u;
    return 1;
}
void gpio_cfg(GPIO_TypeDef *p,unsigned pin,unsigned nibble)
{
    unsigned shift=(pin&7u)*4u;
    volatile uint32_t *cr=pin<8u ? &p->CRL : &p->CRH;
    *cr=(*cr & ~(15u<<shift)) | ((nibble&15u)<<shift);
}
void lights_init(void)
{
    RCC->APB2ENR |= 1u<<2;
    GPIOA->BSRR=(1u<<8)|(1u<<9);    /* off before enabling output */
    gpio_cfg(GPIOA,8,2); gpio_cfg(GPIOA,9,2); /* PP 2MHz */
}
void lights_set(unsigned red)
{
    GPIOA->BSRR = red ? ((1u<<(8+16))|(1u<<9))
                      : ((1u<<8)|(1u<<(9+16)));
}
void tick_init(void)
{
    RCC->APB1ENR |= 1u;
    TIM2->CR1=0; TIM2->DIER=0;
    TIM2->PSC=7; TIM2->ARR=999;     /* 8MHz / 8 / 1000 = 1kHz */
    TIM2->EGR=1; TIM2->SR=0; TIM2->CNT=0;
    NVIC_SetPriorityGrouping(3);   /* 4 preempt bits for this device */
    NVIC_SetPriority(TIM2_IRQn,2);
    NVIC_ClearPendingIRQ(TIM2_IRQn); NVIC_EnableIRQ(TIM2_IRQn);
    TIM2->DIER=1; TIM2->CR1=1;
}
void TIM2_IRQHandler(void)
{
    if (TIM2->SR & 1u) { TIM2->SR=(uint16_t)~1u; ++ms; }
}
