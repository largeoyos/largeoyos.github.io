#ifndef CH8_BOARD_H
#define CH8_BOARD_H
#include "stm32f10x.h"
#include <stdint.h>
int board_clock_8mhz(void);
void gpio_cfg(GPIO_TypeDef *port, unsigned pin, unsigned nibble);
void lights_init(void);
void lights_set(unsigned red);
void tick_init(void);
extern volatile uint32_t ms;
#endif
