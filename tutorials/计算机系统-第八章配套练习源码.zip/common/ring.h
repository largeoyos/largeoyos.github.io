#ifndef CH8_RING_H
#define CH8_RING_H
#include <stdint.h>
#define RING_N 128u
typedef struct { volatile uint8_t data[RING_N]; volatile uint16_t head,tail; } Ring;
static inline int ring_put(Ring *r,uint8_t c)
{
    uint16_t next=(uint16_t)((r->head+1u)&(RING_N-1u));
    if(next==r->tail) return 0;
    r->data[r->head]=c; r->head=next; return 1;
}
static inline int ring_get(Ring *r,uint8_t *c)
{
    if(r->head==r->tail) return 0;
    *c=r->data[r->tail]; r->tail=(uint16_t)((r->tail+1u)&(RING_N-1u)); return 1;
}
#endif
