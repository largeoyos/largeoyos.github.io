#include "uart_irq.h"
#include "ring.h"
static Ring rxq,txq;
volatile uint32_t uart_dropped,uart_errors;
void uart_init(uint32_t baud)
{
    RCC->APB2ENR |= (1u<<2)|(1u<<14);
    gpio_cfg(GPIOA,9,11); gpio_cfg(GPIOA,10,4); /* AF_PP 50MHz / floating */
    USART1->CR1=0; USART1->CR2=0; USART1->CR3=0;
    USART1->BRR=(8000000u+baud/2u)/baud; /* valid nonzero baud, 8MHz PCLK2 */
    rxq.head=rxq.tail=txq.head=txq.tail=0;
    uart_dropped=uart_errors=0;
    (void)USART1->SR; (void)USART1->DR;
    NVIC_SetPriorityGrouping(3);
    NVIC_SetPriority(USART1_IRQn,1);
    NVIC_ClearPendingIRQ(USART1_IRQn); NVIC_EnableIRQ(USART1_IRQn);
    USART1->CR1=(1u<<13)|(1u<<3)|(1u<<2)|(1u<<5); /* UE TE RE RXNEIE */
}
int uart_put(uint8_t c)
{
    uint32_t old=__get_PRIMASK(); int ok;
    __disable_irq();
    ok=ring_put(&txq,c);
    if(ok) USART1->CR1 |= 1u<<7;
    __set_PRIMASK(old);
    return ok;
}
int uart_get(uint8_t *c)
{
    uint32_t old=__get_PRIMASK(); int ok;
    __disable_irq(); ok=ring_get(&rxq,c); __set_PRIMASK(old); return ok;
}
int uart_line(const char *s)
{
    /* Atomic all-or-none enqueue; payload <= 63 bytes. No ISR caller. */
    unsigned n=0,i,free; uint32_t old;
    while(s[n] && n<=63u) ++n;
    if(n>63u) return 0;
    old=__get_PRIMASK(); __disable_irq();
    free=(txq.tail-txq.head-1u)&(RING_N-1u);
    if(free<n+1u) { __set_PRIMASK(old); return 0; }
    for(i=0;i<n;++i) (void)ring_put(&txq,(uint8_t)s[i]);
    (void)ring_put(&txq,'\n'); USART1->CR1 |= 1u<<7;
    __set_PRIMASK(old); return 1;
}
void USART1_IRQHandler(void)
{
    uint32_t sr=USART1->SR; uint8_t c;
    if(sr & ((1u<<5)|15u)) {
        c=(uint8_t)USART1->DR;  /* read after SR: service RX / clear errors */
        if(sr&15u) ++uart_errors;
        else if((sr&(1u<<5)) && !ring_put(&rxq,c)) ++uart_dropped;
    }
    if((USART1->SR&(1u<<7)) && (USART1->CR1&(1u<<7))) {
        if(ring_get(&txq,&c)) USART1->DR=c;
        else USART1->CR1 &= ~(1u<<7);
    }
}
