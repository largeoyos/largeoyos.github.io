#ifndef CH8_UART_H
#define CH8_UART_H
#include "board.h"
void uart_init(uint32_t baud);
int uart_get(uint8_t *c);
int uart_put(uint8_t c);
int uart_line(const char *s);
extern volatile uint32_t uart_dropped,uart_errors;
#endif
