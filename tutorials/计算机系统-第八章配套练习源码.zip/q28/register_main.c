#include "stm32f10x.h"
int main(void)
{
    RCC->APB2ENR |= 1u<<4;
    GPIOC->BSRR=1u<<6;
    GPIOC->CRL=(GPIOC->CRL&~(15u<<24))|(3u<<24);
    for(;;) { }
}
