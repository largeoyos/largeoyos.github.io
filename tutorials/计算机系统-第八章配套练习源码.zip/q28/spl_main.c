#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
int main(void)
{
    GPIO_InitTypeDef g;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
    GPIO_SetBits(GPIOC,GPIO_Pin_6);
    GPIO_StructInit(&g);
    g.GPIO_Pin=GPIO_Pin_6; g.GPIO_Mode=GPIO_Mode_Out_PP;
    g.GPIO_Speed=GPIO_Speed_50MHz; GPIO_Init(GPIOC,&g);
    for(;;) { }
}
