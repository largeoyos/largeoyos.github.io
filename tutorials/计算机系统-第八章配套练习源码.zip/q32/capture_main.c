#include "board.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_tim.h"
volatile uint32_t period_us,frequency_hz,overcapture;
static uint16_t previous;
static unsigned have_previous;
void TIM2_IRQHandler(void)
{
    uint32_t sr=TIM2->SR;
    if(sr&(1u<<2)) {
        uint16_t current=(uint16_t)TIM2->CCR2;
        TIM2->SR=(uint16_t)~((1u<<2)|(1u<<10));
        if(sr&(1u<<10)) { ++overcapture; have_previous=0; }
        if(have_previous) {
            uint16_t delta=(uint16_t)(current-previous);
            if(delta) { period_us=delta; frequency_hz=1000000u/delta; }
        }
        previous=current; have_previous=1;
    }
}
int main(void)
{
    GPIO_InitTypeDef g; TIM_TimeBaseInitTypeDef t; TIM_ICInitTypeDef ic;
    if(!board_clock_8mhz()) for(;;) { }
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
    GPIO_StructInit(&g); g.GPIO_Pin=GPIO_Pin_1;
    g.GPIO_Mode=GPIO_Mode_IN_FLOATING; GPIO_Init(GPIOA,&g);
    TIM_TimeBaseStructInit(&t); t.TIM_Prescaler=7;
    t.TIM_Period=65535; t.TIM_CounterMode=TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2,&t);
    TIM_ICStructInit(&ic); ic.TIM_Channel=TIM_Channel_2;
    ic.TIM_ICPolarity=TIM_ICPolarity_Rising;
    ic.TIM_ICSelection=TIM_ICSelection_DirectTI;
    ic.TIM_ICPrescaler=TIM_ICPSC_DIV1; ic.TIM_ICFilter=0;
    TIM_ICInit(TIM2,&ic); TIM2->EGR=1; TIM2->SR=0;
    NVIC_SetPriorityGrouping(3); NVIC_SetPriority(TIM2_IRQn,1);
    NVIC_ClearPendingIRQ(TIM2_IRQn); NVIC_EnableIRQ(TIM2_IRQn);
    TIM_ITConfig(TIM2,TIM_IT_CC2,ENABLE); TIM_Cmd(TIM2,ENABLE);
    for(;;) { } /* inspect period_us/frequency_hz; valid period <65536us */
}
