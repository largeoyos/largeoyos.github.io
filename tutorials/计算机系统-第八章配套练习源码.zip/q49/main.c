#include "board.h"
#define RED_MS 20000u
#define GREEN_MS 30000u
#define USE_BUTTON 1
static volatile unsigned press_events;
static volatile uint32_t last_press;
static void button_init(void)
{
    RCC->APB2ENR |= (1u<<4)|1u;  /* GPIOC + AFIO */
    GPIOC->BSRR=1u<<5; gpio_cfg(GPIOC,5,8); /* pull-up */
    AFIO->EXTICR[1]=(AFIO->EXTICR[1]&~(15u<<4))|(2u<<4);
    EXTI->IMR &= ~(1u<<5); EXTI->RTSR &= ~(1u<<5);
    EXTI->FTSR |= 1u<<5; EXTI->PR=1u<<5;
    NVIC_SetPriority(EXTI9_5_IRQn,1);
    NVIC_ClearPendingIRQ(EXTI9_5_IRQn); NVIC_EnableIRQ(EXTI9_5_IRQn);
    last_press=ms-20u; EXTI->IMR |= 1u<<5;
}
void EXTI9_5_IRQHandler(void)
{
    if(EXTI->PR&(1u<<5)) {
        uint32_t now=ms;
        EXTI->PR=1u<<5;
        if((uint32_t)(now-last_press)>=20u && !(GPIOC->IDR&(1u<<5))) {
            last_press=now; ++press_events;
        }
    }
}
int main(void)
{
    unsigned red=1,seen=0; uint32_t start,now;
    if(!board_clock_8mhz()) for(;;) { }
    lights_init(); tick_init(); lights_set(red); start=ms;
    if(USE_BUTTON) button_init();
    for(;;) {
        now=ms;
        if(seen!=press_events) {
            unsigned events=press_events-seen;
            seen+=events; red^=events&1u;
            lights_set(red); start=now; /* accepted press resets phase */
        }
        if((uint32_t)(now-start)>=(red?RED_MS:GREEN_MS)) {
            red^=1u; lights_set(red); start=now;
        }
    }
}
