#include "board.h"
static int send_byte(uint8_t c)
{
    uint32_t wait=1000000u;
    while(!(USART1->SR&(1u<<7)) && --wait) { }
    if(!wait) return 0;
    USART1->DR=c; return 1;
}
int main(void)
{
    const char *s="you are welcome"; uint32_t wait;
    if(!board_clock_8mhz()) for(;;) { }
    RCC->APB2ENR |= (1u<<2)|(1u<<14);
    gpio_cfg(GPIOA,9,11); gpio_cfg(GPIOA,10,4);
    USART1->CR1=0; USART1->CR2=0; USART1->CR3=0;
    USART1->BRR=(8000000u+4800u)/9600u;
    USART1->CR1=(1u<<13)|(1u<<3)|(1u<<2); /* 9600 8N1 */
    while(*s) if(!send_byte((uint8_t)*s++)) for(;;) { }
    wait=1000000u;
    while(!(USART1->SR&(1u<<6)) && --wait) { }
    for(;;) { } /* timeout is a bounded failure path; no silent infinite wait */
}
