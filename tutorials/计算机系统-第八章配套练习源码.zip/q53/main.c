#include "board.h"
#include "uart_irq.h"
#include <string.h>
volatile unsigned link_done,link_timeout,protocol_errors;
int main(void)
{
    char line[64]; unsigned used=0,discard=0,got_hello=0,got_ack=0;
    unsigned hello_queued=0,ack_needed=0; uint32_t start; uint8_t c;
    if(!board_clock_8mhz()) for(;;) { }
    tick_init(); uart_init(9600); start=ms;
    for(;;) {
        if(!hello_queued) hello_queued=uart_line("HELLO");
        if(ack_needed && uart_line("ACK")) ack_needed=0;
        while(uart_get(&c)) {
            if(c=='\r') continue;
            if(c=='\n') {
                if(!discard) {
                    line[used]=0;
                    if(!strcmp(line,"HELLO")) { got_hello=1; ack_needed=1; }
                    else if(!strcmp(line,"ACK")) got_ack=1;
                    else ++protocol_errors;
                }
                used=0; discard=0;
            } else if(!discard) {
                if(used<sizeof(line)-1u) line[used++]=(char)c;
                else { discard=1; ++protocol_errors; }
            }
        }
        if(uart_dropped || uart_errors) { link_timeout=1; break; }
        if(got_hello && got_ack && !ack_needed) { link_done=1; break; }
        if((uint32_t)(ms-start)>=3000u) { link_timeout=1; break; }
    }
    /* Interrupts keep draining any queued ACK after the main handshake completes. */
    for(;;) { }
}
