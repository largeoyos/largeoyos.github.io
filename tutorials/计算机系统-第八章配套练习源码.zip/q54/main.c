#include "board.h"
#include "uart_irq.h"
int main(void)
{
    uint8_t c=0; unsigned have=0;
    if(!board_clock_8mhz()) for(;;) { }
    uart_init(9600);
    for(;;) {
        if(!have) have=(unsigned)uart_get(&c);
        if(have && uart_put(c)) have=0; /* do not lose a byte on a full TX queue */
    }
}
